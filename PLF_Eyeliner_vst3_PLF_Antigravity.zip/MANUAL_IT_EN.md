# PLF Eyeliner — User Manual / Manuale Utente
*Multitrack Phase Alignment & Sum Engine for Ableton Live*

---

## 🇮🇹 ITALIANO

### 1. Panoramica
**PLF Eyeliner** è un plugin VST3 progettato per risolvere chirurgicamente i problemi di fase, comb-filtering e dispersione transitoria nelle registrazioni multitraccia su **Ableton Live**. 

Ispirato esteticamente al rigore e all'eleganza hardware del **Weiss DS1-MK3**, combina un telaio in alluminio bianco spazzolato (`#F4F4F2`), serigrafie nere ad alta definizione e un display centrale LCD scuro (`#141416`) con fosfori verdi e ambra.

---

### 2. Architettura Master & Track Companion
1. **Tracce Companion (Insert)**:
   - Inserisci un'istanza di *PLF Eyeliner* su ogni traccia audio correlata (es. Snare Top, Snare Bottom, Overheads, Bass DI, Bass Mic, Lead Vocal, Vocal Doubles).
   - Nel selettore in basso a sinistra, imposta il ruolo su `TRACCIA COMPANION (INSERT)`.
   - Seleziona il numero di traccia (es. `Traccia 1`, `Traccia 2`, ecc.).
2. **Master Coordinator (Bus o Gruppo)**:
   - Inserisci un'istanza di *PLF Eyeliner* sul Bus di gruppo (es. Drum Bus o Vocal Bus).
   - Lascia il ruolo su `COORDINATORE MASTER`.
   - Seleziona la **Traccia di Riferimento (Anchor)**: la traccia fondamentale su cui allineare le altre (es. la cassa o il microfono rullante principale).

---

### 3. Workflow di Allineamento Rapido
1. Avvia la riproduzione in Ableton Live su una sezione rappresentativa del brano.
2. Clicca sul pulsante **`ANALYZE`** sul Master:
   - Il LED centrale lampeggerà in ambra durante la lettura dei ring-buffer audio.
   - All'istante, l'algoritmo calcola la cross-correlazione a risoluzione sub-campione (interpolatore Hermite a 4 punti) e la polarità ottimale.
   - Il LED diventa **Verde Brillante Fisso** e il report sul display LCD mostrerà la tabella diagnostica con ritardi calcolati, inversione di polarità e guadagno in decibel della somma costruttiva.
3. **Ascolto e Confronto A/B**:
   - Clicca su **`A`** per ascoltare la riproduzione grezza originale (Dry).
   - Clicca su **`B`** per ascoltare la riproduzione allineata in fase (Wet).
4. **Undo / Redo**:
   - Usa i tasti `<-` e `->` per muoverti tra le storicizzazioni di allineamento effettuate.
5. **Switch Lingua**:
   - Clicca sul tasto `[LINGUA: ITA / ENG]` in alto a destra nell'LCD per tradurre istantaneamente l'intera interfaccia e il report.

---

### 4. Installazione su Windows
1. Esegui con doppio click lo script:
   ```cmd
   scripts\install_vst3.bat
   ```
2. Lo script richiede automaticamente i privilegi di amministratore se necessario e copia `PLF Eyeliner.vst3` nella cartella standard di sistema:
   `C:\Program Files\Common Files\VST3`
3. In Ableton Live, apri **Preferences -> Plug-ins** e clicca su **Rescan**.

---
---

## 🇬🇧 ENGLISH

### 1. Overview
**PLF Eyeliner** is a precision VST3 audio plugin engineered to eliminate phase cancellation, comb filtering, and transient smearing in multitrack sessions inside **Ableton Live**.

Aesthetically modeled after the legendary **Weiss DS1-MK3**, it features a brushed matte-white aluminum chassis (`#F4F4F2`), deep charcoal silk-screen typography, and a centered obsidian LCD matrix (`#141416`) with glowing green and amber indicators.

---

### 2. Master & Companion Architecture
1. **Track Companion (Insert)**:
   - Drop an instance of *PLF Eyeliner* onto each individual track (e.g. Snare Top, Snare Bottom, Overheads, Room, Vocal Stacks).
   - Set the role selector to `TRACK COMPANION (INSERT)`.
   - Assign the track index (`Track 1`, `Track 2`, etc.).
2. **Master Coordinator (Bus)**:
   - Drop an instance of *PLF Eyeliner* onto the group/bus track.
   - Set the role to `MASTER COORDINATOR`.
   - Select the **Reference Track (Anchor)**: the anchor track against which all other tracks are aligned.

---

### 3. Step-by-Step Alignment
1. Start playback in Ableton Live across an active section of your project.
2. Click **`ANALYZE`** on the Master instance:
   - The central LED pulses amber during cross-correlation analysis.
   - The engine automatically computes sub-sample micro-delays using 4-point Hermite interpolation and tests phase inversion.
   - The LED locks to **Solid Luminous Green**, and the interactive LCD displays a complete per-track diagnostic table detailing delay offsets, polarity flips, and constructive summing gain.
3. **Instant A/B Auditioning**:
   - Press **`A`** to hear the unaligned raw sound.
   - Press **`B`** to hear the phase-locked sum.
4. **Undo / Redo History**:
   - Use `<-` and `->` to step back and forth through previous alignment states.
5. **Bilingual Support**:
   - Toggle the `[LANG: ENG / ITA]` button directly on the LCD panel to switch languages on the fly.

---

### 4. Windows Installation
1. Double click:
   ```cmd
   scripts\install_vst3.bat
   ```
2. The script copies `PLF Eyeliner.vst3` directly to:
   `C:\Program Files\Common Files\VST3`
3. In Ableton Live, navigate to **Preferences -> Plug-ins** and trigger **Rescan**.
