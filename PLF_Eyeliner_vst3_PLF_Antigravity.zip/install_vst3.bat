@echo off
setlocal EnableDelayedExpansion

echo =====================================================================
echo           PLF EYELINER - VST3 INSTALLER PER WINDOWS
echo     Multitrack Phase Alignment Engine per Ableton Live
echo =====================================================================
echo.

set "DEST_DIR=%CommonProgramFiles%\VST3"
if "%DEST_DIR%"=="" set "DEST_DIR=C:\Program Files\Common Files\VST3"

set "BUNDLE_NAME=PLF Eyeliner.vst3"
set "SRC_DIR=%~dp0..\build\PLFEyeliner_artefacts\Release\VST3\%BUNDLE_NAME%"

:: Alternative build paths
if not exist "%SRC_DIR%" (
    set "SRC_DIR=%~dp0..\build\Release\VST3\%BUNDLE_NAME%"
)
if not exist "%SRC_DIR%" (
    set "SRC_DIR=%~dp0..\%BUNDLE_NAME%"
)

echo [1/3] Verifica permessi di amministratore...
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [ATTENZIONE] Richiesti permessi di amministratore per la cartella di sistema:
    echo            %DEST_DIR%
    echo Rilancio dello script come Amministratore...
    powershell -Command "Start-Process cmd -ArgumentList '/c \"\"%~f0\"\"' -Verb RunAs"
    exit /b
)

echo [2/3] Verifica bundle sorgente...
if not exist "%SRC_DIR%" (
    echo [ERRORE] Il file VST3 compilato non e' stato trovato nel percorso previsto:
    echo         "%SRC_DIR%"
    echo.
    echo Assicurati di aver compilato il progetto con:
    echo   scripts\build_release.bat
    echo oppure copia manualmente la cartella '%BUNDLE_NAME%' nella directory di installazione.
    echo.
    pause
    exit /b 1
)

echo [3/3] Installazione in corso...
if not exist "%DEST_DIR%" (
    mkdir "%DEST_DIR%"
)

set "TARGET_PATH=%DEST_DIR%\%BUNDLE_NAME%"

echo Copia da:
echo   "%SRC_DIR%"
echo A:
echo   "%TARGET_PATH%"
echo.

if exist "%TARGET_PATH%" (
    echo Rilevata installazione precedente. Rimozione in corso...
    rmdir /S /Q "%TARGET_PATH%" 2>nul
)

xcopy /E /I /Y /H /K "%SRC_DIR%" "%TARGET_PATH%" >nul

if %errorLevel% equ 0 (
    echo.
    echo =====================================================================
    echo [SUCCESSO] 'PLF Eyeliner.vst3' installato correttamente!
    echo Percorso: %TARGET_PATH%
    echo.
    echo Prossimi passi in Ableton Live:
    echo  1. Apri Ableton Live
    echo  2. Vai in Preferences -> Plug-ins
    echo  3. Clicca su "Rescan"
    echo  4. Trova 'PLF Eyeliner' sotto 'VST3 / PLF Audio'
    echo =====================================================================
) else (
    echo.
    echo [ERRORE] Errore durante la copia del bundle VST3. Codice errore: %errorLevel%
)

echo.
pause
