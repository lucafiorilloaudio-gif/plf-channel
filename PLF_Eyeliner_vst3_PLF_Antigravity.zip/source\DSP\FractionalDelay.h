#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <vector>
#include <cmath>

namespace PLFEyeliner
{
    /**
     * High-precision fractional delay line using 4-point Hermite cubic interpolation.
     * Guarantees smooth, glitch-free micro-delay shifts and phase-accurate reconstruction.
     */
    class FractionalDelay
    {
    public:
        FractionalDelay() = default;

        void prepare(double newSampleRate, int maxDelayInSamples, int numChannels)
        {
            sampleRate = newSampleRate;
            channels = numChannels;
            bufferLength = maxDelayInSamples + 16;
            
            buffer.setSize(channels, bufferLength);
            buffer.clear();
            
            writePosition = 0;
            currentDelaySamples = 0.0f;
            targetDelaySamples = 0.0f;
            currentPolarity = 1.0f;
            targetPolarity = 1.0f;
        }

        void reset()
        {
            buffer.clear();
            writePosition = 0;
        }

        void setTargetDelayMs(float delayMs)
        {
            targetDelaySamples = std::max(0.0f, (delayMs / 1000.0f) * static_cast<float>(sampleRate));
        }

        void setPolarityInverted(bool inverted)
        {
            targetPolarity = inverted ? -1.0f : 1.0f;
        }

        void process(juce::AudioBuffer<float>& inOutBuffer, bool isBypassedOrStateA)
        {
            int numSamples = inOutBuffer.getNumSamples();
            int numChannels = std::min(inOutBuffer.getNumChannels(), channels);
            
            // Smoothing factor for delay changes (tau ~ 20ms)
            const float smoothing = static_cast<float>(1.0 - std::exp(-1.0 / (0.020 * sampleRate)));
            const float polaritySmoothing = static_cast<float>(1.0 - std::exp(-1.0 / (0.005 * sampleRate)));

            for (int s = 0; s < numSamples; ++s)
            {
                // Smooth parameter updates
                float effectiveTargetDelay = isBypassedOrStateA ? 0.0f : targetDelaySamples;
                float effectiveTargetPolarity = isBypassedOrStateA ? 1.0f : targetPolarity;

                currentDelaySamples += (effectiveTargetDelay - currentDelaySamples) * smoothing;
                currentPolarity += (effectiveTargetPolarity - currentPolarity) * polaritySmoothing;

                for (int ch = 0; ch < numChannels; ++ch)
                {
                    float inSample = inOutBuffer.getSample(ch, s);
                    
                    // Write to circular delay buffer
                    buffer.setSample(ch, writePosition, inSample);

                    // Read with fractional Hermite interpolation
                    float readPos = static_cast<float>(writePosition) - currentDelaySamples;
                    while (readPos < 0.0f) readPos += static_cast<float>(bufferLength);
                    
                    int i0 = static_cast<int>(readPos);
                    float frac = readPos - static_cast<float>(i0);
                    
                    int i_prev = (i0 - 1 + bufferLength) % bufferLength;
                    int i_curr = i0 % bufferLength;
                    int i_next = (i0 + 1) % bufferLength;
                    int i_next2 = (i0 + 2) % bufferLength;

                    float ym1 = buffer.getSample(ch, i_prev);
                    float y0  = buffer.getSample(ch, i_curr);
                    float y1  = buffer.getSample(ch, i_next);
                    float y2  = buffer.getSample(ch, i_next2);

                    // 4-point Hermite cubic interpolation
                    float c0 = y0;
                    float c1 = 0.5f * (y1 - ym1);
                    float c2 = ym1 - 2.5f * y0 + 2.0f * y1 - 0.5f * y2;
                    float c3 = 0.5f * (y2 - ym1) + 1.5f * (y0 - y1);
                    
                    float delayedSample = ((c3 * frac + c2) * frac + c1) * frac + c0;

                    // Apply polarity inversion and output
                    inOutBuffer.setSample(ch, s, delayedSample * currentPolarity);
                }

                writePosition = (writePosition + 1) % bufferLength;
            }
        }

    private:
        double sampleRate = 44100.0;
        int channels = 2;
        int bufferLength = 16384;
        juce::AudioBuffer<float> buffer;
        int writePosition = 0;
        
        float currentDelaySamples = 0.0f;
        float targetDelaySamples = 0.0f;
        float currentPolarity = 1.0f;
        float targetPolarity = 1.0f;
    };
}
