#include "LcdDisplayComponent.h"

namespace PLFEyeliner
{
    LcdDisplayComponent::LcdDisplayComponent()
    {
        // Language switcher button inside the LCD frame
        langButton.setButtonText(Localization::getText("LANG_BTN", currentLanguage));
        langButton.setColour(juce::TextButton::buttonColourId, juce::Colour(0xFF222228));
        langButton.setColour(juce::TextButton::textColourOffId, Colors::LedAmberBright);
        langButton.setColour(juce::TextButton::textColourOnId, Colors::LedAmberBright);
        langButton.onClick = [this]()
        {
            if (currentLanguage == Language::Italian)
                setLanguage(Language::English);
            else
                setLanguage(Language::Italian);

            if (onLanguageChanged)
                onLanguageChanged(currentLanguage);
        };
        addAndMakeVisible(langButton);

        // Phase correlation meter
        addAndMakeVisible(phaseMeter);

        // Report text display
        reportDisplay.setMultiLine(true);
        reportDisplay.setReadOnly(true);
        reportDisplay.setScrollbarsShown(true);
        reportDisplay.setCaretVisible(false);
        reportDisplay.setColour(juce::TextEditor::backgroundColourId, juce::Colour(0xFF0E0E10));
        reportDisplay.setColour(juce::TextEditor::textColourId, Colors::LedGreenBright.withAlpha(0.92f));
        reportDisplay.setColour(juce::TextEditor::outlineColourId, juce::Colour(0xFF24242A));
        reportDisplay.setFont(juce::Font("Consolas", 12.0f, juce::Font::plain));
        addAndMakeVisible(reportDisplay);

        refreshReportText();
    }

    void LcdDisplayComponent::setLanguage(Language lang)
    {
        currentLanguage = lang;
        langButton.setButtonText(Localization::getText("LANG_BTN", currentLanguage));
        refreshReportText();
        repaint();
    }

    void LcdDisplayComponent::updateStatus(AnalyzeStatus status, float correlation, const std::vector<AlignmentResult>& results, double sampleRate, int trackCount)
    {
        currentStatus = status;
        currentCorrelation = correlation;
        lastResults = results;
        currentSampleRate = sampleRate;
        activeTrackCount = trackCount;

        phaseMeter.setCorrelation(correlation);
        refreshReportText();
        repaint();
    }

    void LcdDisplayComponent::refreshReportText()
    {
        juce::String r;
        r << Localization::getText("REPORT_HEADER", currentLanguage) << "\n";
        
        juce::String statusStr;
        if (currentStatus == AnalyzeStatus::Idle)
            statusStr = Localization::getText("STATUS_IDLE", currentLanguage);
        else if (currentStatus == AnalyzeStatus::Capturing)
            statusStr = Localization::getText("STATUS_CAPTURING", currentLanguage);
        else
            statusStr = Localization::getText("STATUS_ALIGNED", currentLanguage);

        r << (currentLanguage == Language::Italian ? "STATO ENGINE: " : "ENGINE STATUS: ") << statusStr << "\n";
        r << (currentLanguage == Language::Italian ? "TRACCE ATTIVE: " : "ACTIVE TRACKS: ") << activeTrackCount 
          << " | FS: " << juce::String(static_cast<int>(currentSampleRate)) << " Hz\n";
        r << "--------------------------------------------------------------------------------\n";

        if (lastResults.empty())
        {
            r << "\n" << Localization::getText("REPORT_NO_TRACKS", currentLanguage) << "\n\n";
            r << (currentLanguage == Language::Italian 
                ? "-> Metti in riproduzione Ableton Live e clicca 'ANALYZE' per allineare."
                : "-> Start Ableton Live playback and click 'ANALYZE' to align.");
        }
        else
        {
            // Table header
            r << juce::String::formatted("%-16s | %-16s | %-14s | %-14s | %-10s\n",
                (currentLanguage == Language::Italian ? "TRACCIA" : "TRACK"),
                (currentLanguage == Language::Italian ? "RITARDO (ms)" : "DELAY (ms)"),
                (currentLanguage == Language::Italian ? "POLARITÀ" : "POLARITY"),
                (currentLanguage == Language::Italian ? "CORRELAZIONE" : "CORRELATION"),
                (currentLanguage == Language::Italian ? "GUADAGNO" : "SUM GAIN"));
            r << "--------------------------------------------------------------------------------\n";

            for (const auto& item : lastResults)
            {
                juce::String polStr = item.invertPolarity ? 
                    Localization::getText("POLARITY_INVERTED", currentLanguage) : 
                    Localization::getText("POLARITY_NORMAL", currentLanguage);

                juce::String delayStr = juce::String(item.delayMs, 2) + " ms (" + juce::String(item.delaySamples, 1) + " smp)";
                juce::String corrStr = juce::String::formatted("%.1f%%", item.alignedCorrelation * 100.0f);
                juce::String gainStr = juce::String::formatted("+%.1f dB", item.sumGainDb);

                r << juce::String::formatted("%-16s | %-16s | %-14s | %-14s | %-10s\n",
                    item.trackName.substring(0, 15).toRawUTF8(),
                    delayStr.toRawUTF8(),
                    polStr.toRawUTF8(),
                    corrStr.toRawUTF8(),
                    gainStr.toRawUTF8());
            }

            r << "--------------------------------------------------------------------------------\n";
            r << Localization::getText("REPORT_STATUS_OK", currentLanguage);
        }

        reportDisplay.setText(r, false);
    }

    void LcdDisplayComponent::resized()
    {
        auto bounds = getLocalBounds().reduced(12);

        // Top bar in LCD
        auto topBar = bounds.removeFromTop(28);
        langButton.setBounds(topBar.removeFromRight(110).reduced(2));

        bounds.removeFromTop(6);

        // Phase meter area
        auto meterArea = bounds.removeFromTop(36);
        phaseMeter.setBounds(meterArea);

        bounds.removeFromTop(8);

        // Report text area
        reportDisplay.setBounds(bounds);
    }

    void LcdDisplayComponent::paint(juce::Graphics& g)
    {
        auto bounds = getLocalBounds().toFloat();

        // Outer dark chassis screen bezel
        g.setColour(Colors::LcdBackground);
        g.fillRoundedRectangle(bounds, 5.0f);

        // Inset border shadow
        g.setColour(Colors::LcdBevelBorder);
        g.drawRoundedRectangle(bounds, 5.0f, 1.5f);

        // LCD Header text
        g.setFont(juce::Font("Consolas", 11.0f, juce::Font::bold));
        g.setColour(Colors::LedGreenBright.withAlpha(0.9f));
        g.drawText("PLF EYELINER // MULTITRACK PHASE MATRIX", 14, 14, 340, 20, juce::Justification::centredLeft, false);

        // Subtle phosphor grid effect in background
        g.setColour(Colors::LcdGridLine.withAlpha(0.3f));
        for (int y = 40; y < getHeight() - 10; y += 16)
        {
            g.drawHorizontalLine(y, 12.0f, (float)getWidth() - 12.0f);
        }
    }
}
