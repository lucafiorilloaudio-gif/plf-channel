# PLF Eyeliner — VST3 Multitrack Phase Alignment Engine

[![VST3 Native](https://img.shields.io/badge/Format-VST3_64bit-blue.svg)](https://www.steinberg.net/vst3/)
[![Target DAW](https://img.shields.io/badge/DAW-Ableton_Live_11/12-orange.svg)](https://www.ableton.com/)
[![Aesthetic](https://img.shields.io/badge/Design-Weiss_DS1--MK3-lightgrey.svg)](#gui--design-weiss-ds1-mk3-aesthetic)
[![Antigravity Hub](https://img.shields.io/badge/Portal-Antigravity_Verified-brightgreen.svg)](#antigravity-web-portal-ready)

**PLF Eyeliner** is a high-precision VST3 audio plugin engineered for Windows to automate multitrack phase alignment, transient matching, and constructive summation in **Ableton Live**.

---

## 📸 Architecture & Design

### Master / Track Companion Topology

```mermaid
flowchart TD
    subgraph Ableton_Live_Multitrack ["Ableton Live Project"]
        T1["Track 1 (Kick / Anchor)\n[PLF Companion 1]"]
        T2["Track 2 (Snare Top)\n[PLF Companion 2]"]
        T3["Track 3 (Snare Bottom)\n[PLF Companion 3]"]
        T4["Track 4 (Overhead Pair)\n[PLF Companion 4]"]
    end

    subgraph InProcessRegistry ["Shared In-Process Memory Manager"]
        BufferPool["Circular Audio Ring Buffers\n(Last 3.5s Stereo Audio)"]
        SyncState["Lock-free Synced Offsets\n& Polarity Inversion"]
    end

    subgraph MasterInstance ["Master Group Bus"]
        MasterUI["PLF Eyeliner Master Coordinator\n[Weiss DS1-MK3 Console UI]"]
        DSP_Engine["Hermite Sub-Sample\nCross-Correlation & Transient Matcher"]
    end

    T1 -->|Push Audio Buffer| BufferPool
    T2 -->|Push Audio Buffer| BufferPool
    T3 -->|Push Audio Buffer| BufferPool
    T4 -->|Push Audio Buffer| BufferPool

    MasterUI -->|Click ANALYZE| DSP_Engine
    DSP_Engine -->|Fetch Multi-track Audio| BufferPool
    DSP_Engine -->|Compute Sub-sample Offsets| SyncState
    SyncState -->|Realtime Delay & Polarity Modulation| T1
    SyncState -->|Realtime Delay & Polarity Modulation| T2
    SyncState -->|Realtime Delay & Polarity Modulation| T3
    SyncState -->|Realtime Delay & Polarity Modulation| T4
```

---

## 🎛️ Key Features

1. **Weiss DS1-MK3 Minimalist Hardware Look**:
   - Ultra-clean brushed white matte chassis (`#F4F4F2`).
   - Deep obsidian LCD central panel (`#141416`) with phosphor green (`#27E870`) and amber (`#FF9F0A`) indicators.
   - Embedded stylized **PLF** monogram logo in the upper header.
   - Strictly bounded responsive typography — guaranteed **zero visual overlap or text clipping**.
2. **Sub-Sample Alignment DSP**:
   - 4-point Hermite cubic fractional delay interpolation.
   - Transient onset and normalized cross-correlation analysis over rolling circular buffers.
   - Automatic optimal polarity flipping ($0^\circ / 180^\circ$) to eliminate destructive comb-filtering.
3. **Auditioning & Non-Destructive Workflow**:
   - Dedicated tactile **`ANALYZE`** button with tri-state status LED (Dim Amber -> Pulsing -> Locked Green).
   - Dedicated **`A / B`** comparison buttons with LEDs (A = Original Raw, B = Phase Aligned).
   - Full **`<- UNDO`** and **`REDO ->`** navigation stack.
4. **Bilingual Diagnostic Report**:
   - Real-time scrollable diagnostic report displaying per-track delay offsets, polarity status, and constructive sum gain (+dB).
   - Instant live language switcher (`[ITA | ENG]`) directly within the LCD screen.
5. **Turnkey Deployment**:
   - Automated batch installation script (`scripts\install_vst3.bat`) deploying directly to standard Windows location (`C:\Program Files\Common Files\VST3`).
   - Ready for packaging on the **Antigravity Web Portal**.

---

## 📁 Project Structure

```
plf-eyeliner/
├── CMakeLists.txt                # CMake build script (JUCE 8 FetchContent + C++20)
├── web_portal_manifest.json      # Antigravity Marketplace & Web Portal manifest
├── README.md                     # Technical documentation & overview
├── MANUAL_IT_EN.md               # User manual (Italiano / English)
├── resources/
│   ├── plf_logo.png              # Custom PLF logo graphic
│   └── EmbeddedAssets.h          # Binary embedded asset data in C++
├── scripts/
│   ├── build_release.bat         # Automated Visual Studio 2022 Release build
│   └── install_vst3.bat          # Automated deployment to Common Files\VST3
└── source/
    ├── Common/
    │   ├── Constants.h           # Color palette, DSP limits, enums
    │   ├── Localization.h        # Bilingual string dictionary (ITA/ENG)
    │   └── SharedRegistry.h      # In-process lock-free companion instance registry
    ├── DSP/
    │   ├── AlignmentEngine.h     # Cross-correlation & transient alignment core
    │   ├── AlignmentEngine.cpp   # Sub-sample quadratic peak interpolation
    │   ├── FractionalDelay.h     # 4-point Hermite fractional delay line
    │   └── HistoryManager.h      # Snapshot history stack for Undo/Redo
    ├── GUI/
    │   ├── WeissLookAndFeel.h    # Custom Weiss DS1-MK3 hardware component styling
    │   ├── WeissLookAndFeel.cpp  # Knobs, buttons, bevels, and LEDs
    │   ├── PhaseCorrelationMeter.h # Precision horizontal correlation meter
    │   ├── LcdDisplayComponent.h # Obsidian LCD component with table & language toggle
    │   ├── LcdDisplayComponent.cpp
    │   ├── PluginEditor.h        # Master plugin editor window
    │   └── PluginEditor.cpp      # Layout, animations, and typography
    ├── PluginProcessor.h         # Core VST3 audio processor & state serialization
    └── PluginProcessor.cpp
```

---

## 🛠️ Build & Installation

### Option 1: Automated Script (Recommended)
1. Run `scripts\build_release.bat`. This configures CMake with Visual Studio 2022 (x64), compiles the plugin in `Release` mode, and prompts you to install it automatically.
2. The installer will copy `PLF Eyeliner.vst3` into:
   ```
   C:\Program Files\Common Files\VST3\PLF Eyeliner.vst3
   ```

### Option 2: Manual CMake Build
```powershell
mkdir build
cd build
cmake -G "Visual Studio 17 2022" -A x64 ..
cmake --build . --config Release --target PLFEyeliner_VST3
```

---

## 🌐 Antigravity Web Portal Ready
The project includes `web_portal_manifest.json` fully configured with metadata, compatibility tags, and description for instant indexing and publication on the Antigravity Plugin Hub.
