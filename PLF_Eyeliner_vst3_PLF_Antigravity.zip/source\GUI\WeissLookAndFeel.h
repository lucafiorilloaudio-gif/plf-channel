#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "../Common/Constants.h"

namespace PLFEyeliner
{
    class WeissLookAndFeel : public juce::LookAndFeel_V4
    {
    public:
        WeissLookAndFeel();
        ~WeissLookAndFeel() override = default;

        void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                              float sliderPosProportional, float rotaryStartAngle,
                              float rotaryEndAngle, juce::Slider& slider) override;

        void drawButtonBackground(juce::Graphics& g, juce::Button& button,
                                  const juce::Colour& backgroundColour,
                                  bool shouldDrawButtonAsHighlighted,
                                  bool shouldDrawButtonAsDown) override;

        void drawButtonText(juce::Graphics& g, juce::TextButton& button,
                            bool shouldDrawButtonAsHighlighted,
                            bool shouldDrawButtonAsDown) override;

        void drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                          int buttonX, int buttonY, int buttonW, int buttonH,
                          juce::ComboBox& box) override;

        static void drawLed(juce::Graphics& g, juce::Rectangle<float> bounds, juce::Colour ledColor, bool isOn);
    };
}
