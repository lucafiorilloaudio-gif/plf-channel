#pragma once
#include <juce_graphics/juce_graphics.h>
#include <cstdint>

namespace PLFEyeliner
{
    // =========================================================================
    // Product & Version Info
    // =========================================================================
    constexpr const char* PLUGIN_NAME        = "PLF Eyeliner";
    constexpr const char* PLUGIN_SUBTITLE    = "MULTITRACK PHASE ALIGNMENT & SUM ENGINE";
    constexpr const char* PLUGIN_VERSION     = "1.0.0";
    constexpr const char* PLUGIN_VENDOR      = "PLF Audio & Antigravity";

    // =========================================================================
    // DSP & Alignment Configuration
    // =========================================================================
    constexpr int    MAX_TRACKS              = 32;
    constexpr double MAX_ANALYSIS_SECONDS    = 3.5;       // Analysis ring buffer length
    constexpr double MAX_DELAY_MS            = 120.0;     // Maximum delay shift range (+/-)
    constexpr double MIN_TRANSIENT_THRESHOLD = 0.05;      // RMS gate for active audio
    constexpr int    CORRELATION_WINDOW_SIZE = 8192;      // FFT/Direct correlation window
    constexpr float  CROSSFADE_TIME_MS       = 15.0f;     // Anti-click crossfade on switches

    // =========================================================================
    // Weiss DS1-MK3 Aesthetic Palette (#F4F4F2 Chassis / #141416 LCD)
    // =========================================================================
    namespace Colors
    {
        const juce::Colour ChassisMatteWhite  = juce::Colour(0xFFF4F4F2);
        const juce::Colour ChassisBorderEdge  = juce::Colour(0xFFDCDCDA);
        const juce::Colour SilkScreenBlack    = juce::Colour(0xFF18181A);
        const juce::Colour SilkScreenDim      = juce::Colour(0xFF6B6B70);
        
        const juce::Colour LcdBackground      = juce::Colour(0xFF121214);
        const juce::Colour LcdBevelBorder     = juce::Colour(0xFF2C2C30);
        const juce::Colour LcdGridLine        = juce::Colour(0xFF1E2124);
        
        // Phosphor / LED Indicators
        const juce::Colour LedGreenBright     = juce::Colour(0xFF27E870);
        const juce::Colour LedGreenDim        = juce::Colour(0xFF0F5428);
        const juce::Colour LedAmberBright     = juce::Colour(0xFFFF9F0A);
        const juce::Colour LedAmberDim        = juce::Colour(0xFF663E00);
        const juce::Colour LedRedPhaseCancel  = juce::Colour(0xFFFF453A);
        const juce::Colour LedOff             = juce::Colour(0xFF2A2A2E);
        
        // Buttons
        const juce::Colour ButtonSurface      = juce::Colour(0xFFE8E8E6);
        const juce::Colour ButtonBorder       = juce::Colour(0xFFBDBDBA);
        const juce::Colour ButtonDown         = juce::Colour(0xFFD0D0CE);
    }

    // =========================================================================
    // Enums
    // =========================================================================
    enum class PluginRole
    {
        Master = 0,
        TrackCompanion = 1
    };

    enum class ComparisonState
    {
        StateA_Original = 0,
        StateB_Aligned = 1
    };

    enum class AnalyzeStatus
    {
        Idle = 0,
        Capturing = 1,
        Aligned = 2
    };

    enum class Language
    {
        Italian = 0,
        English = 1
    };
}
