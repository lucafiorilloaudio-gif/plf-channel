#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "../Common/Constants.h"

namespace PLFEyeliner
{
    class PhaseCorrelationMeter : public juce::Component
    {
    public:
        PhaseCorrelationMeter() = default;

        void setCorrelation(float newCorrelation)
        {
            targetCorrelation = juce::jlimit(-1.0f, 1.0f, newCorrelation);
            // Smooth response
            currentCorrelation += (targetCorrelation - currentCorrelation) * 0.25f;
            repaint();
        }

        void paint(juce::Graphics& g) override
        {
            auto bounds = getLocalBounds().toFloat().reduced(2.0f);

            // Background LCD recessed trough
            g.setColour(juce::Colour(0xFF0C0C0E));
            g.fillRoundedRectangle(bounds, 3.0f);
            g.setColour(Colors::LcdBevelBorder);
            g.drawRoundedRectangle(bounds, 3.0f, 1.0f);

            float w = bounds.getWidth();
            float h = bounds.getHeight();
            float midX = bounds.getX() + w * 0.5f;

            // Center line (0.0 correlation)
            g.setColour(juce::Colour(0xFF333338));
            g.drawVerticalLine(static_cast<int>(midX), bounds.getY() + 2.0f, bounds.getBottom() - 2.0f);

            // Quarter lines (-0.5 and +0.5)
            float q1 = bounds.getX() + w * 0.25f;
            float q3 = bounds.getX() + w * 0.75f;
            g.setColour(juce::Colour(0xFF222226));
            g.drawVerticalLine(static_cast<int>(q1), bounds.getY() + 4.0f, bounds.getBottom() - 4.0f);
            g.drawVerticalLine(static_cast<int>(q3), bounds.getY() + 4.0f, bounds.getBottom() - 4.0f);

            // Active correlation fill
            float normalized = (currentCorrelation + 1.0f) * 0.5f; // [0.0, 1.0]
            float targetX = bounds.getX() + normalized * w;

            juce::Colour barCol;
            if (currentCorrelation > 0.3f)
                barCol = Colors::LedGreenBright;
            else if (currentCorrelation >= -0.1f)
                barCol = Colors::LedAmberBright;
            else
                barCol = Colors::LedRedPhaseCancel;

            juce::Rectangle<float> fillBar;
            if (currentCorrelation >= 0.0f)
            {
                fillBar = juce::Rectangle<float>(midX, bounds.getY() + 3.0f, targetX - midX, h - 6.0f);
            }
            else
            {
                fillBar = juce::Rectangle<float>(targetX, bounds.getY() + 3.0f, midX - targetX, h - 6.0f);
            }

            g.setColour(barCol.withAlpha(0.75f));
            g.fillRoundedRectangle(fillBar, 2.0f);

            // Cursor line
            g.setColour(juce::Colours::white);
            g.fillRect(targetX - 1.0f, bounds.getY() + 1.0f, 2.0f, h - 2.0f);

            // Text labels (clean, anti-aliased, strictly within meter area)
            g.setFont(juce::Font("Consolas", 10.0f, juce::Font::bold));
            
            // Left: -1 (Red)
            g.setColour(Colors::LedRedPhaseCancel.withAlpha(0.9f));
            g.drawText("-1.0", bounds.getX() + 4.0f, bounds.getY(), 32.0f, h, juce::Justification::centredLeft, false);

            // Center: 0 (Amber)
            g.setColour(Colors::LedAmberBright.withAlpha(0.8f));
            g.drawText("0", midX - 10.0f, bounds.getY(), 20.0f, h, juce::Justification::centred, false);

            // Right: +1 (Green)
            g.setColour(Colors::LedGreenBright.withAlpha(0.9f));
            g.drawText("+1.0", bounds.getRight() - 36.0f, bounds.getY(), 32.0f, h, juce::Justification::centredRight, false);
        }

    private:
        float targetCorrelation = 1.0f;
        float currentCorrelation = 1.0f;
    };
}
