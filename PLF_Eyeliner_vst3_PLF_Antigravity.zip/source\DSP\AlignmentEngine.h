#pragma once
#include "../Common/Constants.h"
#include <juce_core/juce_core.h>
#include <vector>
#include <string>

namespace PLFEyeliner
{
    struct AlignmentResult
    {
        int trackIndex = 0;
        juce::String trackName;
        float delaySamples = 0.0f;
        float delayMs = 0.0f;
        bool invertPolarity = false;
        float rawCorrelation = 0.0f;
        float alignedCorrelation = 0.0f;
        float sumGainDb = 0.0f;
        bool success = false;
    };

    class AlignmentEngine
    {
    public:
        AlignmentEngine() = default;

        /**
         * Computes optimal sub-sample delay and polarity inversion between reference and target.
         */
        static AlignmentResult calculateAlignment(
            const std::vector<float>& reference,
            const std::vector<float>& target,
            double sampleRate,
            float maxSearchWindowMs = 50.0f);

        /**
         * Computes real-time phase correlation coefficient r in [-1.0, +1.0]
         */
        static float computePhaseCorrelation(const float* ch1, const float* ch2, int numSamples);
    };
}
