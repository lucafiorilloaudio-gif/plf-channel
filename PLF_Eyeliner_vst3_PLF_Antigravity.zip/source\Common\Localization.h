#pragma once
#include "Constants.h"
#include <juce_core/juce_core.h>

namespace PLFEyeliner
{
    class Localization
    {
    public:
        static juce::String getText(const juce::String& key, Language lang)
        {
            if (lang == Language::Italian)
                return getItalian(key);
            return getEnglish(key);
        }

    private:
        static juce::String getItalian(const juce::String& key)
        {
            if (key == "TITLE")                     return "PLF Eyeliner";
            if (key == "SUBTITLE")                  return "GESTIONE & ALLINEAMENTO DI FASE MULTITRACCIA";
            if (key == "ROLE_MASTER")               return "COORDINATORE MASTER";
            if (key == "ROLE_COMPANION")            return "TRACCIA COMPANION (INSERT)";
            if (key == "BTN_ANALYZE")               return "ANALYZE";
            if (key == "BTN_UNDO")                  return "<- ANNULLA";
            if (key == "BTN_REDO")                  return "RIPRISTINA ->";
            if (key == "STATE_A")                   return "A (ORIGINALE)";
            if (key == "STATE_B")                   return "B (ALLINEATO)";
            if (key == "STATUS_IDLE")               return "PRONTO / ATTESA ANALISI";
            if (key == "STATUS_CAPTURING")          return "ACQUISIZIONE SEGNALE...";
            if (key == "STATUS_ALIGNED")            return "FASE BLOCCATA / SOMMA COSTRUTTIVA";
            if (key == "CORRELATION_TITLE")         return "METER CORRELAZIONE DI FASE";
            if (key == "REPORT_HEADER")             return "--- REPORT DIAGNOSTICO ALLINEAMENTO FASE ---";
            if (key == "REPORT_NO_TRACKS")          return "Nessuna traccia Companion rilevata. Inserisci PLF Eyeliner sulle singole tracce.";
            if (key == "REPORT_REFERENCE")          return "Traccia di Riferimento (Anchor): ";
            if (key == "REPORT_DELAY_CALC")         return "Ritardo temporale calcolato: ";
            if (key == "REPORT_POLARITY_CALC")      return "Polarità ottimale: ";
            if (key == "REPORT_COHERENCE")          return "Fattore di Somma Costruttiva: ";
            if (key == "REPORT_STATUS_OK")          return "Allineamento applicato con successo.";
            if (key == "POLARITY_NORMAL")           return "NORMALE (0°)";
            if (key == "POLARITY_INVERTED")         return "INVERTITA (180°)";
            if (key == "TRACK_LABEL")               return "Traccia";
            if (key == "LANG_BTN")                  return "LINGUA: ITA";
            if (key == "TOLERANCE")                 return "Tolleranza Finestra (ms)";
            if (key == "AUTO_POLARITY")             return "Auto-Polarità";
            return key;
        }

        static juce::String getEnglish(const juce::String& key)
        {
            if (key == "TITLE")                     return "PLF Eyeliner";
            if (key == "SUBTITLE")                  return "MULTITRACK PHASE ALIGNMENT & SUM ENGINE";
            if (key == "ROLE_MASTER")               return "MASTER COORDINATOR";
            if (key == "ROLE_COMPANION")            return "TRACK COMPANION (INSERT)";
            if (key == "BTN_ANALYZE")               return "ANALYZE";
            if (key == "BTN_UNDO")                  return "<- UNDO";
            if (key == "BTN_REDO")                  return "REDO ->";
            if (key == "STATE_A")                   return "A (RAW / ORIGINAL)";
            if (key == "STATE_B")                   return "B (PHASE ALIGNED)";
            if (key == "STATUS_IDLE")               return "READY / AWAITING ANALYSIS";
            if (key == "STATUS_CAPTURING")          return "CAPTURING AUDIO STREAM...";
            if (key == "STATUS_ALIGNED")            return "PHASE LOCKED / CONSTRUCTIVE SUM";
            if (key == "CORRELATION_TITLE")         return "PHASE CORRELATION METER";
            if (key == "REPORT_HEADER")             return "--- PHASE ALIGNMENT DIAGNOSTIC REPORT ---";
            if (key == "REPORT_NO_TRACKS")          return "No Companion tracks detected. Insert PLF Eyeliner on individual tracks.";
            if (key == "REPORT_REFERENCE")          return "Reference Track (Anchor): ";
            if (key == "REPORT_DELAY_CALC")         return "Calculated time shift: ";
            if (key == "REPORT_POLARITY_CALC")      return "Optimal polarity: ";
            if (key == "REPORT_COHERENCE")          return "Constructive Sum Coherence: ";
            if (key == "REPORT_STATUS_OK")          return "Alignment successfully engaged.";
            if (key == "POLARITY_NORMAL")           return "NORMAL (0°)";
            if (key == "POLARITY_INVERTED")         return "INVERTED (180°)";
            if (key == "TRACK_LABEL")               return "Track";
            if (key == "LANG_BTN")                  return "LANG: ENG";
            if (key == "TOLERANCE")                 return "Window Tolerance (ms)";
            if (key == "AUTO_POLARITY")             return "Auto-Polarity";
            return key;
        }
    };
}
