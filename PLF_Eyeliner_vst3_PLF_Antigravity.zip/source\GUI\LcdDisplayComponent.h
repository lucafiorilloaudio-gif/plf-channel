#pragma once
#include <juce_gui_basics/juce_gui_basics.h>
#include "../Common/Constants.h"
#include "../Common/Localization.h"
#include "../DSP/AlignmentEngine.h"
#include "PhaseCorrelationMeter.h"
#include <vector>

namespace PLFEyeliner
{
    class LcdDisplayComponent : public juce::Component
    {
    public:
        LcdDisplayComponent();
        ~LcdDisplayComponent() override = default;

        void setLanguage(Language lang);
        Language getLanguage() const { return currentLanguage; }

        void updateStatus(AnalyzeStatus status, float correlation, const std::vector<AlignmentResult>& results, double sampleRate, int trackCount);
        void resized() override;
        void paint(juce::Graphics& g) override;

        std::function<void(Language)> onLanguageChanged;

    private:
        Language currentLanguage = Language::Italian;
        AnalyzeStatus currentStatus = AnalyzeStatus::Idle;
        double currentSampleRate = 48000.0;
        int activeTrackCount = 0;
        float currentCorrelation = 1.0f;
        std::vector<AlignmentResult> lastResults;

        juce::TextButton langButton;
        PhaseCorrelationMeter phaseMeter;
        juce::TextEditor reportDisplay;

        void refreshReportText();
    };
}
