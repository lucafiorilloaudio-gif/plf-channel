#pragma once
#include <vector>
#include <map>
#include <juce_core/juce_core.h>

namespace PLFEyeliner
{
    struct TrackSnapshot
    {
        int trackIndex = 0;
        float delayMs = 0.0f;
        bool invertPolarity = false;
    };

    struct SessionSnapshot
    {
        juce::String timestamp;
        std::map<int, TrackSnapshot> tracks;
    };

    class HistoryManager
    {
    public:
        HistoryManager() = default;

        void pushState(const std::map<int, TrackSnapshot>& state)
        {
            // Truncate redo stack if new change happens
            if (currentIndex >= 0 && currentIndex < static_cast<int>(history.size()) - 1)
            {
                history.erase(history.begin() + currentIndex + 1, history.end());
            }

            SessionSnapshot snap;
            snap.timestamp = juce::Time::getCurrentTime().formatted("%H:%M:%S");
            snap.tracks = state;
            history.push_back(snap);
            currentIndex = static_cast<int>(history.size()) - 1;
        }

        bool canUndo() const { return currentIndex > 0; }
        bool canRedo() const { return currentIndex < static_cast<int>(history.size()) - 1; }

        const SessionSnapshot* undo()
        {
            if (canUndo())
            {
                --currentIndex;
                return &history[currentIndex];
            }
            return nullptr;
        }

        const SessionSnapshot* redo()
        {
            if (canRedo())
            {
                ++currentIndex;
                return &history[currentIndex];
            }
            return nullptr;
        }

        const SessionSnapshot* getCurrent() const
        {
            if (currentIndex >= 0 && currentIndex < static_cast<int>(history.size()))
                return &history[currentIndex];
            return nullptr;
        }

        void clear()
        {
            history.clear();
            currentIndex = -1;
        }

    private:
        std::vector<SessionSnapshot> history;
        int currentIndex = -1;
    };
}
