#pragma once
#include "Constants.h"
#include <juce_audio_basics/juce_audio_basics.h>
#include <mutex>
#include <vector>
#include <memory>
#include <atomic>
#include <map>

namespace PLFEyeliner
{
    // =========================================================================
    // Track State Data
    // =========================================================================
    struct TrackCompanionData
    {
        int instanceId = 0;
        int trackIndex = 1;
        juce::String trackName = "Track 1";
        
        // Alignment parameters
        std::atomic<float> targetDelayMs{ 0.0f };
        std::atomic<float> currentDelayMs{ 0.0f };
        std::atomic<bool>  invertPolarity{ false };
        std::atomic<bool>  isBypassed{ false };
        std::atomic<ComparisonState> comparisonState{ ComparisonState::StateB_Aligned };
        
        // Diagnostics & Metering
        std::atomic<float> peakRms{ 0.0f };
        std::atomic<float> correlationScore{ 1.0f };
        
        // Audio Ring Buffer (last N seconds for cross-correlation analysis)
        juce::AudioBuffer<float> ringBuffer;
        std::atomic<int> writePos{ 0 };
        double sampleRate = 44100.0;
        std::mutex bufferMutex;
        
        void initBuffer(double sRate)
        {
            sampleRate = sRate;
            int numSamples = static_cast<int>(sRate * MAX_ANALYSIS_SECONDS);
            if (numSamples <= 0) numSamples = 44100 * 3;
            
            std::lock_guard<std::mutex> lock(bufferMutex);
            ringBuffer.setSize(2, numSamples);
            ringBuffer.clear();
            writePos.store(0);
        }
        
        void pushAudio(const juce::AudioBuffer<float>& input)
        {
            if (ringBuffer.getNumSamples() == 0) return;
            
            std::lock_guard<std::mutex> lock(bufferMutex);
            int bufLen = ringBuffer.getNumSamples();
            int inLen  = input.getNumSamples();
            int curW   = writePos.load();
            
            for (int ch = 0; ch < std::min(ringBuffer.getNumChannels(), input.getNumChannels()); ++ch)
            {
                const float* src = input.getReadPointer(ch);
                float* dst = ringBuffer.getWritePointer(ch);
                
                for (int s = 0; s < inLen; ++s)
                {
                    dst[(curW + s) % bufLen] = src[s];
                }
            }
            writePos.store((curW + inLen) % bufLen);
        }
        
        // Read the most recent linear window of audio (mono sum)
        void getLatestAudioMono(std::vector<float>& dest, int numSamples)
        {
            dest.resize(numSamples, 0.0f);
            if (ringBuffer.getNumSamples() == 0) return;
            
            std::lock_guard<std::mutex> lock(bufferMutex);
            int bufLen = ringBuffer.getNumSamples();
            int curW   = writePos.load();
            int startIdx = (curW - numSamples + bufLen * 2) % bufLen;
            
            int numCh = ringBuffer.getNumChannels();
            for (int s = 0; s < numSamples; ++s)
            {
                int idx = (startIdx + s) % bufLen;
                float sum = 0.0f;
                for (int ch = 0; ch < numCh; ++ch)
                    sum += ringBuffer.getSample(ch, idx);
                dest[s] = sum / static_cast<float>(std::max(1, numCh));
            }
        }
    };

    // =========================================================================
    // Shared Registry (In-Process Singleton for Ableton Live)
    // =========================================================================
    class SharedRegistry
    {
    public:
        static SharedRegistry& getInstance()
        {
            static SharedRegistry instance;
            return instance;
        }

        int registerCompanion(int preferredTrackIndex, const juce::String& name, double sampleRate)
        {
            std::lock_guard<std::mutex> lock(registryMutex);
            int newId = ++nextId;
            auto companion = std::make_shared<TrackCompanionData>();
            companion->instanceId = newId;
            companion->trackIndex = preferredTrackIndex;
            companion->trackName = name.isEmpty() ? ("Track " + juce::String(preferredTrackIndex)) : name;
            companion->initBuffer(sampleRate);
            
            companions[newId] = companion;
            return newId;
        }

        void unregisterCompanion(int instanceId)
        {
            std::lock_guard<std::mutex> lock(registryMutex);
            companions.erase(instanceId);
        }

        std::shared_ptr<TrackCompanionData> getCompanion(int instanceId)
        {
            std::lock_guard<std::mutex> lock(registryMutex);
            auto it = companions.find(instanceId);
            if (it != companions.end())
                return it->second;
            return nullptr;
        }

        std::vector<std::shared_ptr<TrackCompanionData>> getAllCompanions()
        {
            std::lock_guard<std::mutex> lock(registryMutex);
            std::vector<std::shared_ptr<TrackCompanionData>> list;
            for (auto& pair : companions)
                list.push_back(pair.second);
            return list;
        }

        // Broadcast global A/B state to all companions
        void broadcastComparisonState(ComparisonState state)
        {
            std::lock_guard<std::mutex> lock(registryMutex);
            for (auto& pair : companions)
            {
                pair.second->comparisonState.store(state);
            }
        }

        // Global master ID
        void registerMaster(int id) { masterInstanceId.store(id); }
        void unregisterMaster(int id) { if (masterInstanceId.load() == id) masterInstanceId.store(0); }
        bool isMasterActive() const { return masterInstanceId.load() != 0; }

    private:
        SharedRegistry() = default;
        ~SharedRegistry() = default;
        SharedRegistry(const SharedRegistry&) = delete;
        SharedRegistry& operator=(const SharedRegistry&) = delete;

        std::mutex registryMutex;
        std::map<int, std::shared_ptr<TrackCompanionData>> companions;
        std::atomic<int> masterInstanceId{ 0 };
        int nextId{ 0 };
    };
}
