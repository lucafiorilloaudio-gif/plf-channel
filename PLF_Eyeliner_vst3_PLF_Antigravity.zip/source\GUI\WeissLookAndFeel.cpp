#include "WeissLookAndFeel.h"

namespace PLFEyeliner
{
    WeissLookAndFeel::WeissLookAndFeel()
    {
        setColour(juce::ResizableWindow::backgroundColourId, Colors::ChassisMatteWhite);
        setColour(juce::TextButton::buttonColourId, Colors::ButtonSurface);
        setColour(juce::TextButton::textColourOffId, Colors::SilkScreenBlack);
        setColour(juce::TextButton::textColourOnId, Colors::SilkScreenBlack);
        setColour(juce::ComboBox::backgroundColourId, Colors::ButtonSurface);
        setColour(juce::ComboBox::textColourId, Colors::SilkScreenBlack);
        setColour(juce::ComboBox::outlineColourId, Colors::ButtonBorder);
    }

    void WeissLookAndFeel::drawButtonBackground(juce::Graphics& g, juce::Button& button,
                                                const juce::Colour& backgroundColour,
                                                bool shouldDrawButtonAsHighlighted,
                                                bool shouldDrawButtonAsDown)
    {
        auto bounds = button.getLocalBounds().toFloat().reduced(0.5f);
        
        juce::Colour bg = backgroundColour;
        if (shouldDrawButtonAsDown)
            bg = Colors::ButtonDown;
        else if (shouldDrawButtonAsHighlighted)
            bg = bg.brighter(0.05f);

        // Subtle bevel shadow
        g.setColour(Colors::ButtonBorder);
        g.drawRect(bounds, 1.0f);
        
        g.setColour(bg);
        g.fillRect(bounds.reduced(1.0f));

        // Subtle gradient highlight at top
        juce::ColourGradient grad(juce::Colours::white.withAlpha(0.35f), bounds.getX(), bounds.getY(),
                                  juce::Colours::transparentWhite, bounds.getX(), bounds.getY() + bounds.getHeight() * 0.4f, false);
        g.setFillType(grad);
        g.fillRect(bounds.reduced(1.0f));
    }

    void WeissLookAndFeel::drawButtonText(juce::Graphics& g, juce::TextButton& button,
                                          bool shouldDrawButtonAsHighlighted,
                                          bool shouldDrawButtonAsDown)
    {
        juce::Font font("Segoe UI", 13.0f, juce::Font::bold);
        g.setFont(font);
        g.setColour(button.findColour(button.getToggleState() ? juce::TextButton::textColourOnId
                                                              : juce::TextButton::textColourOffId));

        auto textBounds = button.getLocalBounds().reduced(2);
        if (shouldDrawButtonAsDown)
            textBounds = textBounds.translated(0, 1);

        g.drawFittedText(button.getButtonText(), textBounds, juce::Justification::centred, 1);
    }

    void WeissLookAndFeel::drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                                            float sliderPos, float rotaryStartAngle,
                                            float rotaryEndAngle, juce::Slider& slider)
    {
        auto bounds = juce::Rectangle<int>(x, y, width, height).toFloat().reduced(4.0f);
        auto radius = juce::jmin(bounds.getWidth(), bounds.getHeight()) / 2.0f;
        auto toAngle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);
        auto center = bounds.getCentre();

        // Knob body shadow
        g.setColour(juce::Colours::black.withAlpha(0.2f));
        g.fillEllipse(center.x - radius + 1, center.y - radius + 2, radius * 2.0f, radius * 2.0f);

        // Knob outer ring (charcoal/black)
        juce::ColourGradient knobGrad(juce::Colour(0xFF333336), center.x, center.y - radius,
                                      juce::Colour(0xFF1A1A1C), center.x, center.y + radius, false);
        g.setFillType(knobGrad);
        g.fillEllipse(center.x - radius, center.y - radius, radius * 2.0f, radius * 2.0f);

        g.setColour(Colors::SilkScreenBlack);
        g.drawEllipse(center.x - radius, center.y - radius, radius * 2.0f, radius * 2.0f, 1.2f);

        // Indicator needle
        juce::Path p;
        auto pointerLength = radius * 0.75f;
        auto pointerThickness = 2.2f;
        p.addRectangle(-pointerThickness * 0.5f, -radius * 0.9f, pointerThickness, pointerLength);
        p.applyTransform(juce::AffineTransform::rotation(toAngle).translated(center.x, center.y));
        
        g.setColour(juce::Colours::white);
        g.fillPath(p);
    }

    void WeissLookAndFeel::drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                                        int buttonX, int buttonY, int buttonW, int buttonH,
                                        juce::ComboBox& box)
    {
        auto bounds = juce::Rectangle<float>(0, 0, (float)width, (float)height);
        
        g.setColour(Colors::ButtonSurface);
        g.fillRect(bounds);
        
        g.setColour(Colors::ButtonBorder);
        g.drawRect(bounds, 1.0f);

        // Arrow
        juce::Path arrow;
        float ax = (float)buttonX + (float)buttonW * 0.5f;
        float ay = (float)buttonY + (float)buttonH * 0.5f;
        arrow.addTriangle(ax - 4.0f, ay - 2.0f, ax + 4.0f, ay - 2.0f, ax, ay + 3.0f);
        
        g.setColour(Colors::SilkScreenBlack);
        g.fillPath(arrow);
    }

    void WeissLookAndFeel::drawLed(juce::Graphics& g, juce::Rectangle<float> bounds, juce::Colour ledColor, bool isOn)
    {
        // Dark socket ring
        g.setColour(juce::Colour(0xFF1E1E20));
        g.fillEllipse(bounds);
        g.setColour(Colors::SilkScreenBlack);
        g.drawEllipse(bounds, 1.0f);

        auto inner = bounds.reduced(2.0f);
        if (isOn)
        {
            // Glow
            g.setColour(ledColor.withAlpha(0.35f));
            g.fillEllipse(bounds.expanded(2.5f));

            // Core
            juce::ColourGradient ledGrad(juce::Colours::white.withAlpha(0.8f), inner.getCentreX(), inner.getY(),
                                          ledColor, inner.getCentreX(), inner.getBottom(), false);
            g.setFillType(ledGrad);
            g.fillEllipse(inner);
        }
        else
        {
            g.setColour(ledColor.withMultipliedBrightness(0.2f).withAlpha(0.6f));
            g.fillEllipse(inner);
        }
    }
}
