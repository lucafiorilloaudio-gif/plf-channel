#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "Common/Constants.h"
#include "Common/SharedRegistry.h"
#include "DSP/FractionalDelay.h"
#include "DSP/AlignmentEngine.h"
#include "DSP/HistoryManager.h"
#include <atomic>
#include <vector>

namespace PLFEyeliner
{
    class PLFEyelinerAudioProcessor : public juce::AudioProcessor
    {
    public:
        PLFEyelinerAudioProcessor();
        ~PLFEyelinerAudioProcessor() override;

        void prepareToPlay(double sampleRate, int samplesPerBlock) override;
        void releaseResources() override;
        bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
        void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

        juce::AudioProcessorEditor* createEditor() override;
        bool hasEditor() const override { return true; }

        const juce::String getName() const override { return PLUGIN_NAME; }
        bool acceptsMidi() const override { return false; }
        bool producesMidi() const override { return false; }
        bool isMidiEffect() const override { return false; }
        double getTailLengthSeconds() const override { return 0.0; }

        int getNumPrograms() override { return 1; }
        int getCurrentProgram() override { return 0; }
        void setCurrentProgram(int) override {}
        const juce::String getProgramName(int) override { return {}; }
        void changeProgramName(int, const juce::String&) override {}

        void getStateInformation(juce::MemoryBlock& destData) override;
        void setStateInformation(const void* data, int sizeInBytes) override;

        // Role & Routing
        PluginRole getRole() const { return currentRole.load(); }
        void setRole(PluginRole newRole);

        int getTrackIndex() const { return trackIndex.load(); }
        void setTrackIndex(int newIdx);

        int getReferenceTrackIndex() const { return referenceTrackIndex.load(); }
        void setReferenceTrackIndex(int refIdx) { referenceTrackIndex.store(refIdx); }

        // Analysis & DSP control
        void triggerAnalysis();
        AnalyzeStatus getAnalyzeStatus() const { return analyzeStatus.load(); }
        float getRealTimeCorrelation() const { return realTimeCorrelation.load(); }
        std::vector<AlignmentResult> getLastResults();

        // A/B Comparison & History
        ComparisonState getComparisonState() const { return comparisonState.load(); }
        void setComparisonState(ComparisonState state);

        void performUndo();
        void performRedo();
        bool canUndo() const;
        bool canRedo() const;

        // Tuning parameters
        float getToleranceMs() const { return toleranceMs.load(); }
        void setToleranceMs(float ms) { toleranceMs.store(ms); }

        bool isAutoPolarityEnabled() const { return autoPolarity.load(); }
        void setAutoPolarityEnabled(bool enabled) { autoPolarity.store(enabled); }

        int getActiveCompanionCount();

    private:
        int registeredInstanceId = 0;
        std::atomic<PluginRole> currentRole{ PluginRole::Master };
        std::atomic<int> trackIndex{ 1 };
        std::atomic<int> referenceTrackIndex{ 1 };

        std::atomic<AnalyzeStatus> analyzeStatus{ AnalyzeStatus::Idle };
        std::atomic<ComparisonState> comparisonState{ ComparisonState::StateB_Aligned };
        std::atomic<float> realTimeCorrelation{ 1.0f };
        std::atomic<float> toleranceMs{ 50.0f };
        std::atomic<bool> autoPolarity{ true };

        FractionalDelay delayLine;
        HistoryManager historyManager;

        std::mutex resultsMutex;
        std::vector<AlignmentResult> lastResults;

        juce::AudioBuffer<float> localAudioCapture;
        std::atomic<int> captureWritePos{ 0 };

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PLFEyelinerAudioProcessor)
    };
}
