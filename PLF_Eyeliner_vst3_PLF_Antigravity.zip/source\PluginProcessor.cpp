#include "PluginProcessor.h"
#include "GUI/PluginEditor.h"

namespace PLFEyeliner
{
    PLFEyelinerAudioProcessor::PLFEyelinerAudioProcessor()
        : AudioProcessor(BusesProperties()
                         .withInput("Input", juce::AudioChannelSet::stereo(), true)
                         .withOutput("Output", juce::AudioChannelSet::stereo(), true))
    {
    }

    PLFEyelinerAudioProcessor::~PLFEyelinerAudioProcessor()
    {
        if (registeredInstanceId != 0)
        {
            if (currentRole.load() == PluginRole::TrackCompanion)
                SharedRegistry::getInstance().unregisterCompanion(registeredInstanceId);
            else
                SharedRegistry::getInstance().unregisterMaster(registeredInstanceId);
        }
    }

    void PLFEyelinerAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
    {
        int maxDelaySamples = static_cast<int>(sampleRate * (MAX_DELAY_MS / 1000.0) + 1024);
        delayLine.prepare(sampleRate, maxDelaySamples, getTotalNumInputChannels());

        localAudioCapture.setSize(getTotalNumInputChannels(), static_cast<int>(sampleRate * MAX_ANALYSIS_SECONDS));
        localAudioCapture.clear();
        captureWritePos.store(0);

        if (registeredInstanceId == 0)
        {
            if (currentRole.load() == PluginRole::TrackCompanion)
            {
                registeredInstanceId = SharedRegistry::getInstance().registerCompanion(
                    trackIndex.load(), "Track " + juce::String(trackIndex.load()), sampleRate);
            }
            else
            {
                registeredInstanceId = 999;
                SharedRegistry::getInstance().registerMaster(registeredInstanceId);
            }
        }
    }

    void PLFEyelinerAudioProcessor::releaseResources()
    {
        delayLine.reset();
    }

    bool PLFEyelinerAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
    {
        if (layouts.getMainOutputChannelSet() != juce::AudioChannelSet::mono()
            && layouts.getMainOutputChannelSet() != juce::AudioChannelSet::stereo())
            return false;

        if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
            return false;

        return true;
    }

    void PLFEyelinerAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& /*midiMessages*/)
    {
        juce::ScopedNoDenormals noDenormals;
        int numSamples = buffer.getNumSamples();
        int numChannels = buffer.getNumChannels();

        if (numChannels >= 2)
        {
            float corr = AlignmentEngine::computePhaseCorrelation(
                buffer.getReadPointer(0), buffer.getReadPointer(1), numSamples);
            realTimeCorrelation.store(corr);
        }

        // Save into local ring buffer for analysis
        if (localAudioCapture.getNumSamples() > 0)
        {
            int bufLen = localAudioCapture.getNumSamples();
            int curW = captureWritePos.load();
            for (int ch = 0; ch < std::min(numChannels, localAudioCapture.getNumChannels()); ++ch)
            {
                const float* src = buffer.getReadPointer(ch);
                float* dst = localAudioCapture.getWritePointer(ch);
                for (int s = 0; s < numSamples; ++s)
                    dst[(curW + s) % bufLen] = src[s];
            }
            captureWritePos.store((curW + numSamples) % bufLen);
        }

        if (currentRole.load() == PluginRole::TrackCompanion)
        {
            auto comp = SharedRegistry::getInstance().getCompanion(registeredInstanceId);
            if (comp)
            {
                comp->pushAudio(buffer);
                
                // Fetch synced parameters
                float targetDelay = comp->targetDelayMs.load();
                bool invert = comp->invertPolarity.load();
                ComparisonState state = comp->comparisonState.load();
                
                delayLine.setTargetDelayMs(targetDelay);
                delayLine.setPolarityInverted(invert);

                bool isStateA = (state == ComparisonState::StateA_Original);
                delayLine.process(buffer, isStateA);
            }
        }
        else
        {
            // Master can also act as Reference Track (Anchor) or apply master delay
            bool isStateA = (comparisonState.load() == ComparisonState::StateA_Original);
            delayLine.process(buffer, isStateA);
        }
    }

    void PLFEyelinerAudioProcessor::setRole(PluginRole newRole)
    {
        if (currentRole.load() == newRole) return;

        if (registeredInstanceId != 0)
        {
            if (currentRole.load() == PluginRole::TrackCompanion)
                SharedRegistry::getInstance().unregisterCompanion(registeredInstanceId);
            else
                SharedRegistry::getInstance().unregisterMaster(registeredInstanceId);
            registeredInstanceId = 0;
        }

        currentRole.store(newRole);

        if (getSampleRate() > 0)
        {
            if (newRole == PluginRole::TrackCompanion)
            {
                registeredInstanceId = SharedRegistry::getInstance().registerCompanion(
                    trackIndex.load(), "Track " + juce::String(trackIndex.load()), getSampleRate());
            }
            else
            {
                registeredInstanceId = 999;
                SharedRegistry::getInstance().registerMaster(registeredInstanceId);
            }
        }
    }

    void PLFEyelinerAudioProcessor::setTrackIndex(int newIdx)
    {
        trackIndex.store(newIdx);
        if (currentRole.load() == PluginRole::TrackCompanion && registeredInstanceId != 0)
        {
            auto comp = SharedRegistry::getInstance().getCompanion(registeredInstanceId);
            if (comp)
            {
                comp->trackIndex = newIdx;
                comp->trackName = "Track " + juce::String(newIdx);
            }
        }
    }

    void PLFEyelinerAudioProcessor::triggerAnalysis()
    {
        analyzeStatus.store(AnalyzeStatus::Capturing);

        auto companions = SharedRegistry::getInstance().getAllCompanions();
        double sRate = getSampleRate();
        if (sRate <= 0.0) sRate = 44100.0;

        int windowSamples = static_cast<int>(sRate * 2.0); // 2 seconds window
        std::vector<float> refAudio;

        int refIdx = referenceTrackIndex.load();
        std::shared_ptr<TrackCompanionData> refCompanion = nullptr;

        for (auto& c : companions)
        {
            if (c->trackIndex == refIdx)
            {
                refCompanion = c;
                break;
            }
        }

        if (refCompanion)
        {
            refCompanion->getLatestAudioMono(refAudio, windowSamples);
        }
        else if (localAudioCapture.getNumSamples() > 0)
        {
            // Use Master input as reference
            refAudio.resize(windowSamples, 0.0f);
            int bufLen = localAudioCapture.getNumSamples();
            int curW = captureWritePos.load();
            int startIdx = (curW - windowSamples + bufLen * 2) % bufLen;
            for (int s = 0; s < windowSamples; ++s)
            {
                int idx = (startIdx + s) % bufLen;
                refAudio[s] = localAudioCapture.getSample(0, idx);
            }
        }

        std::vector<AlignmentResult> results;
        std::map<int, TrackSnapshot> snapshotMap;

        // Perform cross-correlation alignment for each companion
        for (auto& comp : companions)
        {
            if (comp->trackIndex == refIdx)
            {
                // Anchor track stays at 0 ms / 0 deg
                AlignmentResult refRes;
                refRes.trackIndex = comp->trackIndex;
                refRes.trackName = comp->trackName + " [ANCHOR]";
                refRes.delayMs = 0.0f;
                refRes.delaySamples = 0.0f;
                refRes.invertPolarity = false;
                refRes.alignedCorrelation = 1.0f;
                refRes.sumGainDb = 0.0f;
                refRes.success = true;
                results.push_back(refRes);

                comp->targetDelayMs.store(0.0f);
                comp->invertPolarity.store(false);

                TrackSnapshot snap{ comp->trackIndex, 0.0f, false };
                snapshotMap[comp->trackIndex] = snap;
                continue;
            }

            std::vector<float> tgtAudio;
            comp->getLatestAudioMono(tgtAudio, windowSamples);

            auto res = AlignmentEngine::calculateAlignment(refAudio, tgtAudio, sRate, toleranceMs.load());
            res.trackIndex = comp->trackIndex;
            res.trackName = comp->trackName;

            if (!autoPolarity.load())
                res.invertPolarity = false;

            if (res.success)
            {
                comp->targetDelayMs.store(res.delayMs);
                comp->invertPolarity.store(res.invertPolarity);
                comp->correlationScore.store(res.alignedCorrelation);

                TrackSnapshot snap{ comp->trackIndex, res.delayMs, res.invertPolarity };
                snapshotMap[comp->trackIndex] = snap;
            }
            results.push_back(res);
        }

        historyManager.pushState(snapshotMap);

        {
            std::lock_guard<std::mutex> lock(resultsMutex);
            lastResults = results;
        }

        analyzeStatus.store(AnalyzeStatus::Aligned);
    }

    std::vector<AlignmentResult> PLFEyelinerAudioProcessor::getLastResults()
    {
        std::lock_guard<std::mutex> lock(resultsMutex);
        return lastResults;
    }

    void PLFEyelinerAudioProcessor::setComparisonState(ComparisonState state)
    {
        comparisonState.store(state);
        SharedRegistry::getInstance().broadcastComparisonState(state);
    }

    void PLFEyelinerAudioProcessor::performUndo()
    {
        const auto* snap = historyManager.undo();
        if (!snap) return;

        auto companions = SharedRegistry::getInstance().getAllCompanions();
        for (auto& c : companions)
        {
            auto it = snap->tracks.find(c->trackIndex);
            if (it != snap->tracks.end())
            {
                c->targetDelayMs.store(it->second.delayMs);
                c->invertPolarity.store(it->second.invertPolarity);
            }
        }
    }

    void PLFEyelinerAudioProcessor::performRedo()
    {
        const auto* snap = historyManager.redo();
        if (!snap) return;

        auto companions = SharedRegistry::getInstance().getAllCompanions();
        for (auto& c : companions)
        {
            auto it = snap->tracks.find(c->trackIndex);
            if (it != snap->tracks.end())
            {
                c->targetDelayMs.store(it->second.delayMs);
                c->invertPolarity.store(it->second.invertPolarity);
            }
        }
    }

    bool PLFEyelinerAudioProcessor::canUndo() const { return historyManager.canUndo(); }
    bool PLFEyelinerAudioProcessor::canRedo() const { return historyManager.canRedo(); }

    int PLFEyelinerAudioProcessor::getActiveCompanionCount()
    {
        return static_cast<int>(SharedRegistry::getInstance().getAllCompanions().size());
    }

    void PLFEyelinerAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
    {
        juce::XmlElement xml("PLFEyelinerState");
        xml.setAttribute("role", static_cast<int>(currentRole.load()));
        xml.setAttribute("trackIndex", trackIndex.load());
        xml.setAttribute("refTrackIndex", referenceTrackIndex.load());
        xml.setAttribute("toleranceMs", toleranceMs.load());
        xml.setAttribute("autoPolarity", autoPolarity.load());
        xml.setAttribute("comparisonState", static_cast<int>(comparisonState.load()));
        copyXmlToBinary(xml, destData);
    }

    void PLFEyelinerAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
    {
        std::unique_ptr<juce::XmlElement> xml(getXmlFromBinary(data, sizeInBytes));
        if (xml && xml->hasTagName("PLFEyelinerState"))
        {
            setRole(static_cast<PluginRole>(xml->getIntAttribute("role", 0)));
            setTrackIndex(xml->getIntAttribute("trackIndex", 1));
            setReferenceTrackIndex(xml->getIntAttribute("refTrackIndex", 1));
            toleranceMs.store(static_cast<float>(xml->getDoubleAttribute("toleranceMs", 50.0)));
            autoPolarity.store(xml->getBoolAttribute("autoPolarity", true));
            setComparisonState(static_cast<ComparisonState>(xml->getIntAttribute("comparisonState", 1)));
        }
    }

    juce::AudioProcessorEditor* PLFEyelinerAudioProcessor::createEditor()
    {
        return new PLFEyelinerEditor(*this);
    }

    juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
    {
        return new PLFEyelinerAudioProcessor();
    }
}
