#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include "WeissLookAndFeel.h"
#include "LcdDisplayComponent.h"
#include "../Common/Constants.h"
#include "../Common/Localization.h"
#include "../resources/EmbeddedAssets.h"

namespace PLFEyeliner
{
    class PLFEyelinerAudioProcessor;

    class PLFEyelinerEditor : public juce::AudioProcessorEditor, public juce::Timer
    {
    public:
        explicit PLFEyelinerEditor(PLFEyelinerAudioProcessor& processor);
        ~PLFEyelinerEditor() override;

        void paint(juce::Graphics& g) override;
        void resized() override;
        void timerCallback() override;

    private:
        PLFEyelinerAudioProcessor& audioProcessor;
        WeissLookAndFeel customLookAndFeel;

        // Custom logo image loaded from embedded memory
        juce::Image logoImage;

        // LCD Display
        LcdDisplayComponent lcdDisplay;

        // Controls
        juce::TextButton analyzeButton;
        juce::TextButton undoButton;
        juce::TextButton redoButton;
        juce::TextButton stateAButton;
        juce::TextButton stateBButton;

        juce::ComboBox roleSelector;
        juce::ComboBox trackIndexSelector;
        juce::ComboBox referenceTrackSelector;

        juce::Slider toleranceSlider;
        juce::Label toleranceLabel;

        juce::ToggleButton autoPolarityToggle;

        // State trackers
        Language currentLanguage = Language::Italian;
        AnalyzeStatus analyzeStatus = AnalyzeStatus::Idle;
        ComparisonState currentComparisonState = ComparisonState::StateB_Aligned;
        int pulseCounter = 0;

        void updateControlTexts();
        void setupButtons();

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PLFEyelinerEditor)
    };
}
