#include "PluginEditor.h"
#include "../PluginProcessor.h"

namespace PLFEyeliner
{
    PLFEyelinerEditor::PLFEyelinerEditor(PLFEyelinerAudioProcessor& p)
        : AudioProcessorEditor(&p), audioProcessor(p)
    {
        setLookAndFeel(&customLookAndFeel);

        // Load custom logo from embedded memory
        logoImage = juce::ImageFileFormat::loadFrom(plf_logo_png, plf_logo_png_size);

        // Setup LCD Display
        addAndMakeVisible(lcdDisplay);
        lcdDisplay.onLanguageChanged = [this](Language newLang)
        {
            currentLanguage = newLang;
            updateControlTexts();
        };

        setupButtons();

        // Window Size (Weiss rackmount proportion)
        setSize(980, 560);
        startTimerHz(30);
    }

    PLFEyelinerEditor::~PLFEyelinerEditor()
    {
        stopTimer();
        setLookAndFeel(nullptr);
    }

    void PLFEyelinerEditor::setupButtons()
    {
        // ANALYZE Button
        analyzeButton.setButtonText(Localization::getText("BTN_ANALYZE", currentLanguage));
        analyzeButton.onClick = [this]()
        {
            audioProcessor.triggerAnalysis();
        };
        addAndMakeVisible(analyzeButton);

        // UNDO / REDO
        undoButton.setButtonText(Localization::getText("BTN_UNDO", currentLanguage));
        undoButton.onClick = [this]() { audioProcessor.performUndo(); };
        addAndMakeVisible(undoButton);

        redoButton.setButtonText(Localization::getText("BTN_REDO", currentLanguage));
        redoButton.onClick = [this]() { audioProcessor.performRedo(); };
        addAndMakeVisible(redoButton);

        // State A / B (Original vs Aligned)
        stateAButton.setButtonText("A");
        stateAButton.setClickingTogglesState(true);
        stateAButton.setRadioGroupId(101);
        stateAButton.onClick = [this]()
        {
            audioProcessor.setComparisonState(ComparisonState::StateA_Original);
        };
        addAndMakeVisible(stateAButton);

        stateBButton.setButtonText("B");
        stateBButton.setClickingTogglesState(true);
        stateBButton.setRadioGroupId(101);
        stateBButton.setToggleState(true, juce::dontSendNotification);
        stateBButton.onClick = [this]()
        {
            audioProcessor.setComparisonState(ComparisonState::StateB_Aligned);
        };
        addAndMakeVisible(stateBButton);

        // Role Selector
        roleSelector.addItem(Localization::getText("ROLE_MASTER", currentLanguage), 1);
        roleSelector.addItem(Localization::getText("ROLE_COMPANION", currentLanguage), 2);
        roleSelector.setSelectedId(audioProcessor.getRole() == PluginRole::Master ? 1 : 2, juce::dontSendNotification);
        roleSelector.onChange = [this]()
        {
            audioProcessor.setRole(roleSelector.getSelectedId() == 1 ? PluginRole::Master : PluginRole::TrackCompanion);
            resized();
        };
        addAndMakeVisible(roleSelector);

        // Track Index Selector
        for (int i = 1; i <= MAX_TRACKS; ++i)
            trackIndexSelector.addItem(Localization::getText("TRACK_LABEL", currentLanguage) + " " + juce::String(i), i);
        trackIndexSelector.setSelectedId(audioProcessor.getTrackIndex(), juce::dontSendNotification);
        trackIndexSelector.onChange = [this]()
        {
            audioProcessor.setTrackIndex(trackIndexSelector.getSelectedId());
        };
        addAndMakeVisible(trackIndexSelector);

        // Reference Track Selector (for Master)
        for (int i = 1; i <= MAX_TRACKS; ++i)
            referenceTrackSelector.addItem("Ref: " + Localization::getText("TRACK_LABEL", currentLanguage) + " " + juce::String(i), i);
        referenceTrackSelector.setSelectedId(audioProcessor.getReferenceTrackIndex(), juce::dontSendNotification);
        referenceTrackSelector.onChange = [this]()
        {
            audioProcessor.setReferenceTrackIndex(referenceTrackSelector.getSelectedId());
        };
        addAndMakeVisible(referenceTrackSelector);

        // Tolerance Slider
        toleranceSlider.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        toleranceSlider.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 55, 18);
        toleranceSlider.setRange(10.0, 100.0, 1.0);
        toleranceSlider.setValue(audioProcessor.getToleranceMs());
        toleranceSlider.onValueChange = [this]()
        {
            audioProcessor.setToleranceMs(static_cast<float>(toleranceSlider.getValue()));
        };
        addAndMakeVisible(toleranceSlider);

        toleranceLabel.setText(Localization::getText("TOLERANCE", currentLanguage), juce::dontSendNotification);
        toleranceLabel.setFont(juce::Font("Segoe UI", 11.0f, juce::Font::bold));
        toleranceLabel.setJustificationType(juce::Justification::centred);
        toleranceLabel.setColour(juce::Label::textColourId, Colors::SilkScreenBlack);
        addAndMakeVisible(toleranceLabel);

        // Auto Polarity Toggle
        autoPolarityToggle.setButtonText(Localization::getText("AUTO_POLARITY", currentLanguage));
        autoPolarityToggle.setToggleState(audioProcessor.isAutoPolarityEnabled(), juce::dontSendNotification);
        autoPolarityToggle.onClick = [this]()
        {
            audioProcessor.setAutoPolarityEnabled(autoPolarityToggle.getToggleState());
        };
        addAndMakeVisible(autoPolarityToggle);

        updateControlTexts();
    }

    void PLFEyelinerEditor::updateControlTexts()
    {
        analyzeButton.setButtonText(Localization::getText("BTN_ANALYZE", currentLanguage));
        undoButton.setButtonText(Localization::getText("BTN_UNDO", currentLanguage));
        redoButton.setButtonText(Localization::getText("BTN_REDO", currentLanguage));
        toleranceLabel.setText(Localization::getText("TOLERANCE", currentLanguage), juce::dontSendNotification);
        autoPolarityToggle.setButtonText(Localization::getText("AUTO_POLARITY", currentLanguage));

        int curRoleId = roleSelector.getSelectedId();
        roleSelector.clear();
        roleSelector.addItem(Localization::getText("ROLE_MASTER", currentLanguage), 1);
        roleSelector.addItem(Localization::getText("ROLE_COMPANION", currentLanguage), 2);
        roleSelector.setSelectedId(curRoleId, juce::dontSendNotification);

        repaint();
    }

    void PLFEyelinerEditor::timerCallback()
    {
        pulseCounter++;
        analyzeStatus = audioProcessor.getAnalyzeStatus();
        currentComparisonState = audioProcessor.getComparisonState();

        undoButton.setEnabled(audioProcessor.canUndo());
        redoButton.setEnabled(audioProcessor.canRedo());

        stateAButton.setToggleState(currentComparisonState == ComparisonState::StateA_Original, juce::dontSendNotification);
        stateBButton.setToggleState(currentComparisonState == ComparisonState::StateB_Aligned, juce::dontSendNotification);

        lcdDisplay.updateStatus(
            analyzeStatus,
            audioProcessor.getRealTimeCorrelation(),
            audioProcessor.getLastResults(),
            audioProcessor.getSampleRate(),
            audioProcessor.getActiveCompanionCount());

        repaint();
    }

    void PLFEyelinerEditor::paint(juce::Graphics& g)
    {
        // Matte white brushed aluminum chassis (#F4F4F2)
        g.fillAll(Colors::ChassisMatteWhite);

        // Subtle horizontal brushed metal texture simulation
        g.setColour(juce::Colours::black.withAlpha(0.015f));
        for (int y = 0; y < getHeight(); y += 2)
            g.drawHorizontalLine(y, 0.0f, (float)getWidth());

        // Outer chassis border
        g.setColour(Colors::ChassisBorderEdge);
        g.drawRect(getLocalBounds().toFloat(), 1.5f);

        // Header Section
        auto headerBounds = juce::Rectangle<int>(20, 16, getWidth() - 40, 50);

        // Logo
        if (logoImage.isValid())
        {
            // Maintain aspect ratio, clean rendering
            auto logoRect = juce::Rectangle<float>(24.0f, 16.0f, 54.0f, 40.0f);
            g.drawImage(logoImage, logoRect, juce::RectanglePlacement::centred | juce::RectanglePlacement::onlyReduceInSize);
        }

        // Title and Subtitle (Crisp typography, no overlapping)
        g.setFont(juce::Font("Segoe UI", 22.0f, juce::Font::bold));
        g.setColour(Colors::SilkScreenBlack);
        g.drawText(PLUGIN_NAME, 90, 14, 250, 26, juce::Justification::left, false);

        g.setFont(juce::Font("Segoe UI", 9.5f, juce::Font::plain));
        g.setColour(Colors::SilkScreenDim);
        g.drawText(Localization::getText("SUBTITLE", currentLanguage), 92, 40, 400, 16, juce::Justification::left, false);

        // Right side header info: Weiss-style badge
        g.setFont(juce::Font("Segoe UI", 11.0f, juce::Font::bold));
        g.setColour(Colors::SilkScreenBlack);
        g.drawText("GAMBIT ENGINE // PRECISION MULTITRACK", getWidth() - 360, 24, 330, 20, juce::Justification::right, false);

        // Divider line below header
        g.setColour(Colors::ButtonBorder.withAlpha(0.7f));
        g.drawHorizontalLine(70, 20.0f, (float)getWidth() - 20.0f);

        // Section Dividers in bottom control area
        int bottomSectionY = 410;
        g.drawHorizontalLine(bottomSectionY - 10, 20.0f, (float)getWidth() - 20.0f);

        // Silk screen labels for bottom controls
        g.setFont(juce::Font("Segoe UI", 10.0f, juce::Font::bold));
        g.setColour(Colors::SilkScreenDim);
        g.drawText("ROUTING & INSTANCE", 30, bottomSectionY - 6, 200, 16, juce::Justification::left, false);
        g.drawText("ALIGNMENT CORE", 290, bottomSectionY - 6, 200, 16, juce::Justification::left, false);
        g.drawText("AUDITION & A/B", 490, bottomSectionY - 6, 200, 16, juce::Justification::left, false);
        g.drawText("DETECTION WINDOW", 760, bottomSectionY - 6, 200, 16, juce::Justification::left, false);

        // Draw LEDs
        // 1. ANALYZE button central LED
        auto analyzeBounds = analyzeButton.getBounds().toFloat();
        juce::Rectangle<float> analyzeLedRect(analyzeBounds.getCentreX() - 4.0f, analyzeBounds.getY() - 14.0f, 8.0f, 8.0f);
        
        bool ledOn = false;
        juce::Colour ledColor = Colors::LedGreenBright;
        if (analyzeStatus == AnalyzeStatus::Capturing)
        {
            ledColor = Colors::LedAmberBright;
            ledOn = (pulseCounter % 10) < 5; // Blinking
        }
        else if (analyzeStatus == AnalyzeStatus::Aligned)
        {
            ledColor = Colors::LedGreenBright;
            ledOn = true;
        }
        else
        {
            ledColor = Colors::LedOff;
            ledOn = false;
        }
        WeissLookAndFeel::drawLed(g, analyzeLedRect, ledColor, ledOn);

        // 2. A / B LEDs
        auto aBounds = stateAButton.getBounds().toFloat();
        auto bBounds = stateBButton.getBounds().toFloat();
        juce::Rectangle<float> ledARect(aBounds.getCentreX() - 4.0f, aBounds.getY() - 12.0f, 8.0f, 8.0f);
        juce::Rectangle<float> ledBRect(bBounds.getCentreX() - 4.0f, bBounds.getY() - 12.0f, 8.0f, 8.0f);

        WeissLookAndFeel::drawLed(g, ledARect, Colors::LedGreenBright, currentComparisonState == ComparisonState::StateA_Original);
        WeissLookAndFeel::drawLed(g, ledBRect, Colors::LedGreenBright, currentComparisonState == ComparisonState::StateB_Aligned);
    }

    void PLFEyelinerEditor::resized()
    {
        // Center LCD Display (high visual prominence)
        lcdDisplay.setBounds(24, 80, getWidth() - 48, 305);

        // Bottom Controls area
        int y = 430;

        // Column 1: Routing
        roleSelector.setBounds(28, y, 170, 28);
        trackIndexSelector.setBounds(28, y + 36, 170, 28);
        referenceTrackSelector.setBounds(28, y + 72, 170, 28);

        bool isMaster = (roleSelector.getSelectedId() == 1);
        referenceTrackSelector.setVisible(isMaster);

        // Column 2: Alignment Trigger
        analyzeButton.setBounds(290, y + 10, 160, 48);

        // Column 3: History & A/B
        undoButton.setBounds(490, y, 95, 30);
        redoButton.setBounds(595, y, 95, 30);

        stateAButton.setBounds(515, y + 54, 55, 38);
        stateBButton.setBounds(585, y + 54, 55, 38);

        // Column 4: Parameters (Tolerance & Polarity)
        toleranceSlider.setBounds(760, y - 8, 85, 85);
        toleranceLabel.setBounds(745, y + 78, 115, 20);

        autoPolarityToggle.setBounds(860, y + 20, 100, 30);
    }
}
