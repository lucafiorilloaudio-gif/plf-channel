@echo off
setlocal

echo =====================================================================
echo           PLF EYELINER - COMPILAZIONE RELEASE VST3
echo =====================================================================
echo.

cd /d "%~dp0.."
set "BUILD_DIR=build"

if not exist "%BUILD_DIR%" (
    mkdir "%BUILD_DIR%"
)

cd "%BUILD_DIR%"

echo [1/2] Configurazione CMake con Visual Studio...
cmake -G "Visual Studio 17 2022" -A x64 ..
if %errorLevel% neq 0 (
    echo [ERRORE] Configurazione CMake fallita.
    pause
    exit /b %errorLevel%
)

echo.
echo [2/2] Compilazione target VST3 in modalita' Release...
cmake --build . --config Release --target PLFEyeliner_VST3
if %errorLevel% neq 0 (
    echo [ERRORE] Compilazione fallita.
    pause
    exit /b %errorLevel%
)

echo.
echo =====================================================================
echo [COMPLETATO] Compilazione completata con successo!
echo Bundle generato in:
echo   %cd%\PLFEyeliner_artefacts\Release\VST3\PLF Eyeliner.vst3
echo =====================================================================
echo.

set /p INSTALL_NOW="Vuoi installare automaticamente il plugin in Common Files\VST3 adesso? (S/N): "
if /i "%INSTALL_NOW%"=="S" (
    call "%~dp0install_vst3.bat"
)

pause
