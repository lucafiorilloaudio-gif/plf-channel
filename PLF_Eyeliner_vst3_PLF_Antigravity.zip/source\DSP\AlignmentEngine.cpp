#include "AlignmentEngine.h"
#include <cmath>
#include <algorithm>

namespace PLFEyeliner
{
    float AlignmentEngine::computePhaseCorrelation(const float* ch1, const float* ch2, int numSamples)
    {
        if (numSamples <= 0 || !ch1 || !ch2) return 1.0f;

        double sumProduct = 0.0;
        double sumSquare1 = 0.0;
        double sumSquare2 = 0.0;

        for (int i = 0; i < numSamples; ++i)
        {
            float s1 = ch1[i];
            float s2 = ch2[i];

            sumProduct += s1 * s2;
            sumSquare1 += s1 * s1;
            sumSquare2 += s2 * s2;
        }

        double denominator = std::sqrt(sumSquare1 * sumSquare2);
        if (denominator < 1e-9) return 1.0f; // Silence / inactive

        float correlation = static_cast<float>(sumProduct / denominator);
        return juce::jlimit(-1.0f, 1.0f, correlation);
    }

    AlignmentResult AlignmentEngine::calculateAlignment(
        const std::vector<float>& reference,
        const std::vector<float>& target,
        double sampleRate,
        float maxSearchWindowMs)
    {
        AlignmentResult res;
        int N = static_cast<int>(std::min(reference.size(), target.size()));
        
        if (N < 256 || sampleRate <= 0)
        {
            res.success = false;
            return res;
        }

        // Calculate RMS of signals to check if active
        double refE = 0.0, tgtE = 0.0;
        for (int i = 0; i < N; ++i)
        {
            refE += reference[i] * reference[i];
            tgtE += target[i] * target[i];
        }

        double rmsRef = std::sqrt(refE / N);
        double rmsTgt = std::sqrt(tgtE / N);

        if (rmsRef < 0.001 || rmsTgt < 0.001)
        {
            // Signal too quiet or silence
            res.success = false;
            return res;
        }

        // Search range in samples
        int maxLag = static_cast<int>((maxSearchWindowMs / 1000.0f) * sampleRate);
        maxLag = juce::jlimit(16, N / 4, maxLag);

        // Raw correlation at lag 0
        res.rawCorrelation = computePhaseCorrelation(reference.data(), target.data(), N);

        // Cross-correlation sweep
        double bestCorrelation = 0.0;
        int bestLag = 0;
        bool invertNeeded = false;

        // Window size for cross-correlation evaluation
        int evalLen = N - 2 * maxLag;
        if (evalLen < 128) evalLen = 128;

        std::vector<double> correlationValues(2 * maxLag + 1, 0.0);

        for (int lag = -maxLag; lag <= maxLag; ++lag)
        {
            double sumProd = 0.0;
            double sumR2 = 0.0;
            double sumT2 = 0.0;

            const float* refPtr = reference.data() + maxLag;
            const float* tgtPtr = target.data() + maxLag + lag;

            for (int i = 0; i < evalLen; ++i)
            {
                float r = refPtr[i];
                float t = tgtPtr[i];
                sumProd += r * t;
                sumR2 += r * r;
                sumT2 += t * t;
            }

            double denom = std::sqrt(sumR2 * sumT2);
            double rValue = (denom > 1e-9) ? (sumProd / denom) : 0.0;
            correlationValues[lag + maxLag] = rValue;

            // Check if absolute correlation magnitude is higher
            if (std::abs(rValue) > std::abs(bestCorrelation))
            {
                bestCorrelation = rValue;
                bestLag = lag;
                invertNeeded = (rValue < 0.0);
            }
        }

        // Sub-sample interpolation via quadratic peak fitting
        float subSampleLag = static_cast<float>(bestLag);
        int idx = bestLag + maxLag;
        if (idx > 0 && idx < static_cast<int>(correlationValues.size()) - 1)
        {
            double y_prev = std::abs(correlationValues[idx - 1]);
            double y_curr = std::abs(correlationValues[idx]);
            double y_next = std::abs(correlationValues[idx + 1]);

            double denom = 2.0 * (y_prev - 2.0 * y_curr + y_next);
            if (std::abs(denom) > 1e-8)
            {
                double delta = (y_prev - y_next) / denom;
                delta = juce::jlimit(-0.5, 0.5, delta);
                subSampleLag += static_cast<float>(delta);
            }
        }

        // Positive delay means target needs to be delayed, negative means reference was ahead
        // Since delay lines can only add positive delay, we offset relative to the base
        res.delaySamples = std::max(0.0f, subSampleLag);
        res.delayMs = (res.delaySamples / static_cast<float>(sampleRate)) * 1000.0f;
        res.invertPolarity = invertNeeded;
        res.alignedCorrelation = static_cast<float>(std::abs(bestCorrelation));

        // Theoretical sum energy improvement
        double rawSum = 0.0;
        double alignedSum = 0.0;
        for (int i = 0; i < evalLen; ++i)
        {
            float r = reference[maxLag + i];
            float t_raw = target[maxLag + i];
            float t_aligned = (invertNeeded ? -1.0f : 1.0f) * target[maxLag + i + bestLag];

            float sum1 = r + t_raw;
            float sum2 = r + t_aligned;

            rawSum += sum1 * sum1;
            alignedSum += sum2 * sum2;
        }

        double ratio = (rawSum > 1e-9) ? (alignedSum / rawSum) : 1.0;
        res.sumGainDb = static_cast<float>(10.0 * std::log10(std::max(0.001, ratio)));
        res.success = true;

        return res;
    }
}
