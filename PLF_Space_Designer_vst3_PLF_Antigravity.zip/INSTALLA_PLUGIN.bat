@echo off
chcp 65001 >nul
title Installatore PLF Space Designer VST3 - PLF Audio Lab
color 0B

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Richiesta permessi di amministratore per installare in VST3 di sistema...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs" 2>nul
    exit /b
)

cd /d "%~dp0"
set "TARGET_DIR=C:\Program Files\Common Files\VST3\PLF Audio Lab"
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%" >nul 2>&1

echo Installazione PLF Space Designer in corso...
if exist "%TARGET_DIR%\PLF Space Designer.vst3" rmdir /s /q "%TARGET_DIR%\PLF Space Designer.vst3" >nul 2>&1
xcopy /E /I /Y /Q "%~dp0PLF Space Designer.vst3" "%TARGET_DIR%\PLF Space Designer.vst3" >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%TARGET_DIR%\PLF Space Designer.vst3' -Recurse | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1

echo.
echo =======================================================================
echo   PLF Space Designer INSTALLATO CON SUCCESSO!
echo   Cartella: %TARGET_DIR%\PLF Space Designer.vst3
echo   Tipo Ableton: Effetto Audio
echo =======================================================================
echo Apri Ableton Live ^> Plug-in ^> VST3 ^> PLF Audio Lab!
echo.
pause