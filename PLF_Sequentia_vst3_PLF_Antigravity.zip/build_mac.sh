#!/bin/bash
# =============================================================
#   PLF Antigravity - PLF Sequentia Universal Build Script (macOS)
#   Builds native arm64 (Apple Silicon) + x86_64 (Intel) VST3 & AU
# =============================================================

set -e

echo "Configuring PLF Sequentia Universal Binary build..."
cmake -B build-mac \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" \
    -DCMAKE_OSX_DEPLOYMENT_TARGET="10.13"

echo "Compiling PLF Sequentia VST3, AU, and Standalone..."
cmake --build build-mac --config Release --parallel

echo "Build successful! Artefacts located in: build-mac/PLF_Sequentia_artefacts/Release/"
