@echo off
setlocal enabledelayedexpansion
title PLF Antigravity - PLF Sequentia VST3 Installer
color 0B

echo.
echo  =============================================================
echo    PLF Antigravity - PLF Sequentia VST3 Installer for Windows
echo  =============================================================
echo.

set "SYS_VST3_DIR=C:\Program Files\Common Files\VST3\PLF Antigravity"
set "TARGET=%SYS_VST3_DIR%\PLF Sequentia.vst3"

:: Determine source path
set "SRC=%~dp0PLF Sequentia.vst3"
if not exist "!SRC!" (
    if exist "%~dp0Prebuilt_VST3\PLF Sequentia.vst3" (
        set "SRC=%~dp0Prebuilt_VST3\PLF Sequentia.vst3"
    ) else if exist "%~dp0build\PLF_Sequentia_artefacts\Release\VST3\PLF Sequentia.vst3" (
        set "SRC=%~dp0build\PLF_Sequentia_artefacts\Release\VST3\PLF Sequentia.vst3"
    )
)

if not exist "!SRC!" (
    color 0C
    echo [ERRORE] File 'PLF Sequentia.vst3' non trovato nella cartella corrente o in build!
    echo Assicurati di aver compilato il progetto con CMake.
    echo.
    pause
    exit /b 1
)

:: Check if Ableton Live or other DAW is running
tasklist /FI "IMAGENAME eq Live.exe" 2>NUL | find /I /N "Live.exe">NUL
if "%ERRORLEVEL%"=="0" (
    color 0E
    echo [ATTENZIONE] Ableton Live e attualmente aperto!
    echo Si consiglia di chiudere Ableton Live per permettere la sovrascrittura del plugin.
    echo.
    set /p "RETRY=Premi INVIO dopo aver chiuso Ableton Live per continuare..."
)

echo.
echo [*] Creazione cartella di destinazione: %SYS_VST3_DIR%
if not exist "%SYS_VST3_DIR%" (
    mkdir "%SYS_VST3_DIR%" >nul 2>&1
)

echo [*] Copia di PLF Sequentia.vst3 nella directory VST3 di sistema...
xcopy /E /I /Y /Q "!SRC!" "!TARGET!" >nul 2>&1

if "%ERRORLEVEL%"=="0" (
    color 0A
    echo.
    echo =============================================================
    echo  [SUCCESSO] PLF Sequentia installato correttamente in:
    echo  %TARGET%
    echo =============================================================
    echo.
    echo Per usarlo in Ableton Live:
    echo 1. Riavvia Ableton Live (oppure tieni premuto ALT e clicca su "Rescan Plugins").
    echo 2. Cerca 'PLF Sequentia' nella sezione MIDI Effects (sotto 'PLF Antigravity').
    echo 3. Inseriscilo su una traccia MIDI davanti al tuo synth preferito.
    echo.
) else (
    color 0C
    echo [ERRORE] Errore durante la copia. Prova ad eseguire questo script come Amministratore.
)

pause
