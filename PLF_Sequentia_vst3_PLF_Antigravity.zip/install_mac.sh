#!/bin/bash
# =============================================================
#   PLF Antigravity - PLF Sequentia Installer for macOS
#   Installs VST3 & AU (Component) for Ableton Live on Mac
# =============================================================

echo ""
echo "============================================================="
echo "  PLF Antigravity - PLF Sequentia Installer for macOS"
echo "============================================================="
echo ""

# Destination directories
VST3_DIR="$HOME/Library/Audio/Plug-Ins/VST3/PLF Antigravity"
AU_DIR="$HOME/Library/Audio/Plug-Ins/Components/PLF Antigravity"

mkdir -p "$VST3_DIR"
mkdir -p "$AU_DIR"

# Locate compiled artefacts
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VST3_SRC=""

if [ -d "$SCRIPT_DIR/PLF Sequentia.vst3" ]; then
    VST3_SRC="$SCRIPT_DIR/PLF Sequentia.vst3"
elif [ -d "$SCRIPT_DIR/build/PLF_Sequentia_artefacts/Release/VST3/PLF Sequentia.vst3" ]; then
    VST3_SRC="$SCRIPT_DIR/build/PLF_Sequentia_artefacts/Release/VST3/PLF Sequentia.vst3"
fi

if [ -n "$VST3_SRC" ]; then
    echo "[*] Copying PLF Sequentia.vst3 to $VST3_DIR..."
    cp -R "$VST3_SRC" "$VST3_DIR/"
    # Remove macOS quarantine attribute so Ableton Live loads it without security prompt
    xattr -cr "$VST3_DIR/PLF Sequentia.vst3" 2>/dev/null || true
    echo "[SUCCESS] VST3 installed successfully!"
else
    echo "[WARNING] PLF Sequentia.vst3 not found in current folder or build."
fi

# AudioUnit (AU)
AU_SRC=""
if [ -d "$SCRIPT_DIR/PLF Sequentia.component" ]; then
    AU_SRC="$SCRIPT_DIR/PLF Sequentia.component"
elif [ -d "$SCRIPT_DIR/build/PLF_Sequentia_artefacts/Release/AU/PLF Sequentia.component" ]; then
    AU_SRC="$SCRIPT_DIR/build/PLF_Sequentia_artefacts/Release/AU/PLF Sequentia.component"
fi

if [ -n "$AU_SRC" ]; then
    echo "[*] Copying PLF Sequentia.component to $AU_DIR..."
    cp -R "$AU_SRC" "$AU_DIR/"
    xattr -cr "$AU_DIR/PLF Sequentia.component" 2>/dev/null || true
    echo "[SUCCESS] AU Component installed successfully!"
fi

echo ""
echo "============================================================="
echo "  Installation completed for Ableton Live on Mac!"
echo "  In Ableton Live: Preferences -> Plug-Ins -> Rescan"
echo "============================================================="
echo ""
