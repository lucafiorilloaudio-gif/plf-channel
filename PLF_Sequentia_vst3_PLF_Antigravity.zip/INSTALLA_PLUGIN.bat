@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Installatore PLF Sequentia VST3 - PLF Antigravity
color 0B

:: 1. Verifica ed auto-elevazione come Amministratore (UAC)
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo =====================================================================
    echo    RICHIESTA PERMESSI AMMINISTRATORE (UAC) IN CORSO...
    echo =====================================================================
    echo.
    echo Per installare il plugin nella cartella VST3 di sistema di Windows,
    echo e' necessario concedere i permessi di amministratore.
    echo.
    set "SCRIPT_PATH=%~f0"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:SCRIPT_PATH -Verb RunAs" 2>nul
    if %errorLevel% neq 0 (
        echo.
        echo [AVVISO] Impossibile avviare automaticamente la richiesta UAC.
        echo Fai clic destro su questo file e seleziona "Esegui come amministratore".
        echo.
        pause
    )
    exit /b
)

:: Imposta directory di lavoro nella cartella dove risiede il file .bat
cd /d "%~dp0"

echo =====================================================================
echo            INSTALLATORE AUTOMATICO - PLF Sequentia VST3
echo                     creato da PLF Antigravity
echo =====================================================================
echo.

set "PLUGIN_FOLDER=PLF Sequentia.vst3"
set "SOURCE_DIR=%~dp0PLF Sequentia.vst3"

:: 2. Verifica che il plugin sia presente nella cartella
if not exist "%SOURCE_DIR%" (
    echo [ERRORE] Impossibile trovare la cartella "%PLUGIN_FOLDER%"!
    echo Percorso cercato: "%SOURCE_DIR%"
    echo.
    echo ATTENZIONE: Assicurati di aver ESTRATTO completamente il contenuto
    echo del file .ZIP prima di fare doppio clic su questo file .bat.
    echo (Fai clic destro sul file ZIP -^> Estrai tutto...)
    echo.
    pause
    exit /b 1
)

:: 3. Verifica se Ableton Live e' aperto (evita blocco file VST3)
tasklist /FI "IMAGENAME eq Live.exe" 2>nul | find /I "Live.exe" >nul
if %errorLevel% equ 0 (
    echo =====================================================================
    echo  [ATTENZIONE] Ableton Live risulta attualmente IN ESECUZIONE.
    echo  Per consentire la corretta sovrascrittura del plugin senza errori
    echo  di file bloccato da Windows:
    echo.
    echo   1. Chiudi Ableton Live adesso.
    echo   2. Torna qui e premi un tasto per continuare l'installazione.
    echo =====================================================================
    echo.
    pause
)

:: 4. Definizione percorsi di destinazione VST3 di sistema e utente
set "VST3_SYSTEM=C:\Program Files\Common Files\VST3"
if defined CommonProgramFiles set "VST3_SYSTEM=%CommonProgramFiles%\VST3"

set "TARGET_VENDOR=%VST3_SYSTEM%\PLF Antigravity\%PLUGIN_FOLDER%"
set "TARGET_ROOT=%VST3_SYSTEM%\%PLUGIN_FOLDER%"
set "USER_VST3=%LOCALAPPDATA%\Programs\Common\VST3"

echo [*] Rimozione di eventuali versioni precedenti (pulizia completa)...
if exist "%TARGET_VENDOR%" rmdir /s /q "%TARGET_VENDOR%" >nul 2>&1
if exist "%TARGET_ROOT%" rmdir /s /q "%TARGET_ROOT%" >nul 2>&1
if exist "%USER_VST3%\PLF Antigravity\%PLUGIN_FOLDER%" rmdir /s /q "%USER_VST3%\PLF Antigravity\%PLUGIN_FOLDER%" >nul 2>&1
if exist "%USER_VST3%\%PLUGIN_FOLDER%" rmdir /s /q "%USER_VST3%\%PLUGIN_FOLDER%" >nul 2>&1

echo [*] Creazione cartella VST3 del produttore...
if not exist "%VST3_SYSTEM%\PLF Antigravity" (
    mkdir "%VST3_SYSTEM%\PLF Antigravity" >nul 2>&1
)

echo [*] Installazione nuova versione in VST3 (PLF Antigravity)...
xcopy /E /I /Y /Q "%SOURCE_DIR%" "%TARGET_VENDOR%" >nul
if %errorLevel% neq 0 (
    echo [ERRORE] Errore durante la copia in "%TARGET_VENDOR%".
    pause
    exit /b 1
)

echo [*] Sincronizzazione copia nella cartella principale VST3...
xcopy /E /I /Y /Q "%SOURCE_DIR%" "%TARGET_ROOT%" >nul

echo.
echo =====================================================================
echo           INSTALLAZIONE COMPLETATA CON SUCCESSO!
echo =====================================================================
echo.
echo  Il plugin "PLF Sequentia" e' stato installato e sovrascritto con
echo  l'ultima versione disponibile.
echo.
echo  COME VISUALIZZARLO SUBITO IN ABLETON LIVE:
echo   1. Avvia Ableton Live (scansionera' automaticamente la nuova versione).
echo   2. Nel browser di sinistra, troverai il plugin sotto:
echo      Plug-in -^> VST3 -^> PLF Antigravity -^> PLF Sequentia
echo      (oppure direttamente sotto Plug-in -^> VST3 -^> PLF Sequentia.vst3)
echo.
echo   SUGGERIMENTO: Se non lo vedi subito o vuoi forzare la scansione:
echo   - Vai su Opzioni -^> Preferenze (Ctrl + ,) -^> Scheda "Plug-Ins"
echo   - Tieni premuto il tasto [ALT] sulla tastiera e fai clic su "Rescan".
echo.
echo =====================================================================
pause