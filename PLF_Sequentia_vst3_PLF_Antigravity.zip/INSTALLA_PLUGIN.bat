@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul
title Installatore PLF Sequentia VST3 - PLF Antigravity
color 0B

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Richiesta permessi di amministratore...
    set "SCRIPT_PATH=%~f0"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath $env:SCRIPT_PATH -Verb RunAs" 2>nul
    if %errorLevel% neq 0 (
        echo [AVVISO] Fai clic destro sul file .bat e scegli "Esegui come amministratore"
        echo oppure avvia direttamente il file INSTALLA_*.exe incluso nella cartella.
        pause
    )
    exit /b
)

cd /d "%~dp0"
set "PLUGIN_FOLDER=PLF Sequentia.vst3"
set "SOURCE_DIR=%~dp0PLF Sequentia.vst3"

if not exist "%SOURCE_DIR%" (
    echo [ERRORE] Cartella "%PLUGIN_FOLDER%" non trovata accanto allo script!
    echo Assicurati di aver estratto tutto lo ZIP oppure usa il file .EXE!
    pause
    exit /b 1
)

tasklist /FI "IMAGENAME eq Live.exe" 2>nul | find /I "Live.exe" >nul
if %errorLevel% equ 0 (
    echo [ATTENZIONE] Chiudi Ableton Live prima di proseguire!
    pause
)

set "VST3_SYSTEM=C:\Program Files\Common Files\VST3"
if defined CommonProgramFiles set "VST3_SYSTEM=%CommonProgramFiles%\VST3"
set "TARGET_VENDOR=%VST3_SYSTEM%\PLF Antigravity\%PLUGIN_FOLDER%"
set "TARGET_ROOT=%VST3_SYSTEM%\%PLUGIN_FOLDER%"
set "USER_VST3=%LOCALAPPDATA%\Programs\Common\VST3"

if exist "%TARGET_VENDOR%" rmdir /s /q "%TARGET_VENDOR%" >nul 2>&1
if exist "%TARGET_ROOT%" rmdir /s /q "%TARGET_ROOT%" >nul 2>&1
if exist "%USER_VST3%\PLF Antigravity\%PLUGIN_FOLDER%" rmdir /s /q "%USER_VST3%\PLF Antigravity\%PLUGIN_FOLDER%" >nul 2>&1
if exist "%USER_VST3%\%PLUGIN_FOLDER%" rmdir /s /q "%USER_VST3%\%PLUGIN_FOLDER%" >nul 2>&1

if not exist "%VST3_SYSTEM%\PLF Antigravity" mkdir "%VST3_SYSTEM%\PLF Antigravity" >nul 2>&1
xcopy /E /I /Y /Q "%SOURCE_DIR%" "%TARGET_VENDOR%" >nul
if %errorLevel% neq 0 (
    echo [ERRORE] Copia fallita in "%TARGET_VENDOR%".
    pause
    exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%TARGET_VENDOR%' -Recurse | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1

echo =====================================================================
echo   PLF Sequentia installato con successo in:
echo   %TARGET_VENDOR%
echo   Tipo in Ableton: Strumento / Synth (traccia MIDI)
echo =====================================================================
pause