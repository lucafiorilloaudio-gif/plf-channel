@echo off
chcp 65001 >nul
title Installatore Completo Suite PLF Antigravity VST3 (5 Plugin)
color 0A

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo Richiesta permessi amministratore per installare in VST3 di sistema...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs" 2>nul
    exit /b
)

cd /d "%~dp0"

echo =======================================================================
echo          INSTALLAZIONE SUITE COMPLETA PLF ANTIGRAVITY VST3 (5 PLUGIN)
echo =======================================================================
echo.
echo 1. PLF Space Designer v1.2.1 (Audio FX)
echo 2. PLF Little Cosm v1.1.0    (Audio FX)
echo 3. PLF Sequentia v1.1.0      (MIDI Instrument)
echo 4. PLF Channel v1.1.0        (Audio FX)
echo 5. PLF Eyeliner v1.0.0       (Audio FX - Phase Alignment)
echo.

set "VST3_DIR=C:\Program Files\Common Files\VST3\PLF Antigravity"
if not exist "%VST3_DIR%" mkdir "%VST3_DIR%" >nul 2>&1

for %%P in ("PLF Channel.vst3" "PLF Space Designer.vst3" "PLF Sequentia.vst3" "PLF Little Cosm.vst3" "PLF Eyeliner.vst3") do (
    if exist "%~dp0%%~P" (
        echo Installazione %%~P in corso...
        if exist "%VST3_DIR%\%%~P" rmdir /s /q "%VST3_DIR%\%%~P" >nul 2>&1
        xcopy /E /I /Y /Q "%~dp0%%~P" "%VST3_DIR%\%%~P" >nul
    )
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%VST3_DIR%' -Recurse | Unblock-File -ErrorAction SilentlyContinue" >nul 2>&1

echo.
echo =======================================================================
echo   SUITE COMPLETA INSTALLATA CON SUCCESSO!
echo   Percorso: %VST3_DIR%
echo =======================================================================
echo In Ableton Live:
echo - Apri Opzioni ^> Preferenze ^> Plug-Ins
echo - Assicurati che 'Usa cartella di sistema VST3' sia su SI
echo - Premi ALT + Rescan per rilevare tutti i 5 plugin!
echo.
pause