@echo off
setlocal enabledelayedexpansion
title PLF Antigravity - PLF Little Cosm VST3 Installer
color 0B

echo.
echo  =============================================================
echo    PLF Antigravity - PLF Little Cosm VST3 Installer (Win 64)
echo  =============================================================
echo.

set "SYS_VST3_DIR=%COMMONPROGRAMFILES%\VST3\PLF Antigravity"
set "TARGET=%SYS_VST3_DIR%\PLF Little Cosm.vst3"
set "SRC=%~dp0PLF Little Cosm.vst3"

if not exist "!SRC!" (
    color 0C
    echo [ERRORE] File 'PLF Little Cosm.vst3' non trovato nella cartella corrente!
    pause
    exit /b 1
)

echo [*] Creazione cartella di destinazione: %SYS_VST3_DIR%
if not exist "%SYS_VST3_DIR%" (
    mkdir "%SYS_VST3_DIR%" >nul 2>&1
)

echo [*] Installazione di PLF Little Cosm.vst3...
xcopy /E /I /Y /Q "!SRC!" "!TARGET!" >nul 2>&1

if "%ERRORLEVEL%"=="0" (
    color 0A
    echo.
    echo =============================================================
    echo  [SUCCESSO] PLF Little Cosm installato con successo!
    echo  Percorso: %TARGET%
    echo =============================================================
    echo.
    echo Per usarlo in Ableton Live o nella tua DAW:
    echo 1. Riapri la DAW o fai 'Rescan' dei plug-in VST3.
    echo 2. Troverai 'PLF Little Cosm' negli Audio Effects (PLF Antigravity).
    echo.
) else (
    color 0C
    echo [ERRORE] Impossibile copiare i file. Esegui questo script come Amministratore.
)

pause