@echo off
chcp 65001 >nul
title Installatore PLF Channel VST3 - PLF Antigravity
color 0B

echo =====================================================================
echo            INSTALLATORE AUTOMATICO - PLF CHANNEL VST3
echo                     creato da PLF Antigravity
echo =====================================================================
echo.

:: Verifica se eseguito come amministratore
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [ATTENZIONE] Sono richiesti i privilegi di Amministratore per copiare nella cartella VST3 di sistema.
    echo Fai tasto destro su questo file e seleziona "Esegui come amministratore".
    echo.
    pause
    exit /b 1
)

set "SOURCE_DIR=%~dp0PLF Channel.vst3"
set "TARGET_DIR=C:\Program Files\Common Files\VST3\PLF Antigravity\PLF Channel.vst3"
set "ROOT_VST3=C:\Program Files\Common Files\VST3\PLF Channel.vst3"

if not exist "%SOURCE_DIR%" (
    echo [ERRORE] Impossibile trovare la cartella sorgente "%SOURCE_DIR%".
    echo Assicurati che "PLF Channel.vst3" sia nella stessa cartella di questo script.
    pause
    exit /b 1
)

echo [*] Creazione cartella di destinazione VST3...
if not exist "C:\Program Files\Common Files\VST3\PLF Antigravity" (
    mkdir "C:\Program Files\Common Files\VST3\PLF Antigravity"
)

echo [*] Rimozione di eventuali versioni precedenti...
if exist "%TARGET_DIR%" rmdir /s /q "%TARGET_DIR%"
if exist "%ROOT_VST3%" rmdir /s /q "%ROOT_VST3%"

echo [*] Copia del plugin in C:\Program Files\Common Files\VST3\PLF Antigravity...
xcopy /E /I /Y "%SOURCE_DIR%" "%TARGET_DIR%" >nul

echo [*] Copia di sicurezza nella cartella VST3 principale...
xcopy /E /I /Y "%SOURCE_DIR%" "%ROOT_VST3%" >nul

echo.
echo =====================================================================
echo           INSTALLAZIONE COMPLETATA CON SUCCESSO!
echo =====================================================================
echo.
echo Istruzioni per Ableton Live:
echo  1. Apri Ableton Live.
echo  2. Vai su Opzioni -^> Preferenze (Ctrl + ,) -^> Scheda "Plug-Ins".
echo  3. Verifica che "Usa cartella Plug-in di sistema VST3" sia su SI.
echo  4. Clicca su "Rescan" (o premi Alt + Rescan).
echo  5. Troverai "PLF Channel" nel browser sotto Plug-in -^> VST3 -^> PLF Antigravity!
echo.
pause
